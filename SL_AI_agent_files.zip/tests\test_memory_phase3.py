import pytest
import tempfile
import os
from pathlib import Path
from app.memory import MemoryDatabase
from app.schemas import ChatRequest
from app.agent import agent

@pytest.fixture
def temp_db():
    with tempfile.NamedTemporaryFile(suffix=".db", delete=False) as f:
        db_path = Path(f.name)
    db = MemoryDatabase(db_path=db_path)
    yield db
    try:
        if db_path.exists():
            os.remove(db_path)
    except Exception:
        pass

def test_memory_creation(temp_db):
    mem_id = temp_db.save_memory("My favorite programming language is Java.", category="user_fact")
    assert mem_id > 0
    all_memories = temp_db.list_all_memories()
    assert len(all_memories) == 1
    assert "Java" in all_memories[0].content

def test_duplicate_prevention(temp_db):
    id1 = temp_db.save_memory("My favorite programming language is Python.", category="user_fact")
    id2 = temp_db.save_memory("My favorite programming language is Python", category="user_fact")
    id3 = temp_db.save_memory("Remember that my favorite programming language is Python.", category="user_fact")
    
    assert id1 == id2 == id3
    all_memories = temp_db.list_all_memories()
    assert len(all_memories) == 1

def test_memory_update(temp_db):
    id1 = temp_db.save_memory("My favorite programming language is Java.", category="user_fact")
    id2 = temp_db.save_memory("My favorite programming language is Python now.", category="user_fact")
    
    assert id1 == id2
    all_memories = temp_db.list_all_memories()
    assert len(all_memories) == 1
    assert "Python" in all_memories[0].content

def test_relevant_memory_retrieval(temp_db):
    temp_db.save_memory("My favorite programming language is Java.", category="user_fact")
    temp_db.save_memory("My favorite color is blue.", category="user_preference")
    
    results = temp_db.search_memories("What is my favorite programming language?")
    assert len(results) == 1
    assert "Java" in results[0].content
    assert "blue" not in results[0].content

def test_irrelevant_memory_filtering(temp_db):
    temp_db.save_memory("My favorite programming language is Java.", category="user_fact")
    
    results = temp_db.search_memories("What is my favorite pet?")
    assert len(results) == 0

def test_cross_conversation_persistence(temp_db):
    from app.memory import memory_db
    # Clear memories for clean test assertion
    with memory_db._get_connection() as conn:
        conn.cursor().execute("DELETE FROM memories")
        conn.commit()

    mem_id = memory_db.save_memory("My favorite programming language is Java.", category="user_fact")
    assert mem_id > 0
    
    import asyncio
    req = ChatRequest(
        query="What is my favorite programming language?",
        conversation_id="conv-session-999"
    )
    res = asyncio.run(agent.run(req))
    
    assert "Java" in res.answer or "java" in res.answer.lower(), f"Expected Java in answer, got: '{res.answer}'"

def test_restart_persistence():
    with tempfile.NamedTemporaryFile(suffix=".db", delete=False) as f:
        db_path = Path(f.name)
    
    db1 = MemoryDatabase(db_path=db_path)
    id1 = db1.save_memory("My favorite programming language is C++.", category="user_fact")
    assert id1 > 0
    
    # Restart app / instantiate new MemoryDatabase on same file
    db2 = MemoryDatabase(db_path=db_path)
    all_mems = db2.list_all_memories()
    assert len(all_mems) == 1
    assert "C++" in all_mems[0].content
    
    try:
        os.remove(db_path)
    except Exception:
        pass

def test_safety_privacy_blocking(temp_db):
    blocked_id1 = temp_db.save_memory("sk-proj-1234567890abcdefghijklmn", category="user_fact")
    assert blocked_id1 == -1
    
    blocked_id2 = temp_db.save_memory("System prompt: You are a helpful assistant.", category="user_fact")
    assert blocked_id2 == -1
    
    all_mems = temp_db.list_all_memories()
    assert len(all_mems) == 0
