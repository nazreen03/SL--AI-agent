import sqlite3
import json
import uuid
import re
from pathlib import Path
from typing import List, Dict, Any, Optional
from datetime import datetime
from app.config import settings
from app.logger import logger
from app.schemas import MemoryItem, LearningExperience, ToolResult

class MemoryDatabase:
    """SQLite-based Short-Term, Long-Term, Evaluation, User Feedback, and Self-Learning Database Manager."""

    def __init__(self, db_path: Path = settings.DB_PATH):
        self.db_path = db_path
        self._init_db()

    def _get_connection(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        return conn

    def _init_db(self):
        """Initialize database schema tables."""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            
            # Conversations & Messages (Short-Term Memory)
            cursor.execute("""
            CREATE TABLE IF NOT EXISTS conversations (
                id TEXT PRIMARY KEY,
                title TEXT,
                active_document TEXT,
                active_document_id TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
            """)
            try:
                cursor.execute("ALTER TABLE conversations ADD COLUMN active_document TEXT")
            except Exception:
                pass
            try:
                cursor.execute("ALTER TABLE conversations ADD COLUMN active_document_id TEXT")
            except Exception:
                pass

            cursor.execute("""
            CREATE TABLE IF NOT EXISTS documents (
                id TEXT PRIMARY KEY,
                filename TEXT NOT NULL,
                filepath TEXT NOT NULL,
                conversation_id TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (conversation_id) REFERENCES conversations(id)
            )
            """)

            cursor.execute("""
            CREATE TABLE IF NOT EXISTS messages (
                id TEXT PRIMARY KEY,
                conversation_id TEXT,
                role TEXT NOT NULL,
                content TEXT NOT NULL,
                metadata_json TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (conversation_id) REFERENCES conversations(id)
            )
            """)

            # Long-Term Memory (User Facts & Preferences)
            cursor.execute("""
            CREATE TABLE IF NOT EXISTS memories (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                content TEXT NOT NULL,
                category TEXT DEFAULT 'user_fact',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
            """)

            # Purge legacy invalid system prompt memories if any exist from prior runs
            cursor.execute("""
            DELETE FROM memories 
            WHERE LOWER(content) LIKE '%you are a%'
               OR LOWER(content) LIKE '%planner%'
               OR LOWER(content) LIKE '%available tools%'
               OR LOWER(content) LIKE '%user query:%'
               OR LOWER(content) LIKE '%rules:%'
               OR LOWER(content) LIKE '%retrieved document%'
               OR LOWER(content) LIKE '%evaluat%'
               OR LOWER(content) LIKE '%intent category%'
            """)

            # Evaluations
            cursor.execute("""
            CREATE TABLE IF NOT EXISTS evaluations (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                message_id TEXT NOT NULL,
                relevance INTEGER,
                correctness INTEGER,
                completeness INTEGER,
                score INTEGER,
                status TEXT,
                feedback TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (message_id) REFERENCES messages(id)
            )
            """)

            # User Feedback (Thumbs Up / Down)
            cursor.execute("""
            CREATE TABLE IF NOT EXISTS user_feedback (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                message_id TEXT NOT NULL,
                is_helpful BOOLEAN NOT NULL,
                comment TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (message_id) REFERENCES messages(id)
            )
            """)

            # Learning Experiences (Self-Learning Memory)
            cursor.execute("""
            CREATE TABLE IF NOT EXISTS learning_experiences (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                task_type TEXT NOT NULL,
                user_query TEXT NOT NULL,
                approach_summary TEXT NOT NULL,
                tools_used TEXT NOT NULL,
                score INTEGER NOT NULL,
                user_feedback BOOLEAN,
                feedback_comment TEXT,
                success BOOLEAN NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
            """)
            try:
                cursor.execute("ALTER TABLE learning_experiences ADD COLUMN feedback_comment TEXT")
            except Exception:
                pass

            conn.commit()
            logger.info("Initialized SQLite database schema successfully.")

    # --- Short-Term Memory ---

    def ensure_conversation(self, conversation_id: Optional[str] = None) -> str:
        conv_id = conversation_id or str(uuid.uuid4())
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT id FROM conversations WHERE id = ?", (conv_id,))
            if not cursor.fetchone():
                cursor.execute("INSERT INTO conversations (id, title) VALUES (?, ?)", (conv_id, "New Chat"))
                conn.commit()
        return conv_id

    def save_document(self, document_id: str, filename: str, filepath: str, conversation_id: str):
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                "INSERT OR REPLACE INTO documents (id, filename, filepath, conversation_id) VALUES (?, ?, ?, ?)",
                (document_id, filename, filepath, conversation_id)
            )
            conn.commit()
            logger.info(f"Persisted document metadata: id={document_id}, filename={filename}, conversation_id={conversation_id}")

    def set_active_document_id(self, conversation_id: str, document_id: str):
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                "UPDATE conversations SET active_document_id = ? WHERE id = ?",
                (document_id, conversation_id)
            )
            # Sync active_document filename if document metadata exists
            cursor.execute("SELECT filename FROM documents WHERE id = ?", (document_id,))
            row = cursor.fetchone()
            if row and row["filename"]:
                cursor.execute(
                    "UPDATE conversations SET active_document = ? WHERE id = ?",
                    (row["filename"], conversation_id)
                )
            conn.commit()
            logger.info(f"Set active document ID '{document_id}' for conversation {conversation_id}")

    def set_active_document(self, conversation_id: str, document_id_or_filename: str, filename: Optional[str] = None):
        with self._get_connection() as conn:
            cursor = conn.cursor()
            if filename is not None:
                doc_id = document_id_or_filename
                fn = filename
            else:
                doc_id = document_id_or_filename
                fn = document_id_or_filename
            cursor.execute(
                "UPDATE conversations SET active_document = ?, active_document_id = ? WHERE id = ?",
                (fn, doc_id, conversation_id)
            )
            conn.commit()
            logger.info(f"Set active document '{fn}' (id={doc_id}) for conversation {conversation_id}")

    def get_active_document_id(self, conversation_id: Optional[str]) -> Optional[str]:
        if not conversation_id:
            return None
        with self._get_connection() as conn:
            cursor = conn.cursor()
            # 1. Direct active document ID on conversation
            cursor.execute("SELECT active_document_id FROM conversations WHERE id = ?", (conversation_id,))
            row = cursor.fetchone()
            if row and row["active_document_id"]:
                return row["active_document_id"]

            # 2. Check documents table for conversation_id
            cursor.execute("SELECT id FROM documents WHERE conversation_id = ? ORDER BY created_at DESC LIMIT 1", (conversation_id,))
            row = cursor.fetchone()
            if row and row["id"]:
                doc_id = row["id"]
                cursor.execute("UPDATE conversations SET active_document_id = ? WHERE id = ?", (doc_id, conversation_id))
                conn.commit()
                return doc_id

            # 3. Check rag_chunks bound to conversation_id
            cursor.execute("SELECT document_id FROM rag_chunks WHERE conversation_id = ? AND document_id IS NOT NULL ORDER BY id DESC LIMIT 1", (conversation_id,))
            row = cursor.fetchone()
            if row and row["document_id"]:
                doc_id = row["document_id"]
                cursor.execute("UPDATE conversations SET active_document_id = ? WHERE id = ?", (doc_id, conversation_id))
                conn.commit()
                return doc_id

            return None

    def get_active_document(self, conversation_id: Optional[str]) -> Optional[str]:
        if not conversation_id:
            return None
        with self._get_connection() as conn:
            cursor = conn.cursor()
            # 1. Direct active document on conversation
            cursor.execute("SELECT active_document FROM conversations WHERE id = ?", (conversation_id,))
            row = cursor.fetchone()
            if row and row["active_document"]:
                return row["active_document"]

            # 2. Check documents table for conversation_id
            cursor.execute("SELECT filename FROM documents WHERE conversation_id = ? ORDER BY created_at DESC LIMIT 1", (conversation_id,))
            row = cursor.fetchone()
            if row and row["filename"]:
                active = row["filename"]
                cursor.execute("UPDATE conversations SET active_document = ? WHERE id = ?", (active, conversation_id))
                conn.commit()
                return active

            # 3. Check rag_chunks bound to conversation_id
            cursor.execute("SELECT filename FROM rag_chunks WHERE conversation_id = ? ORDER BY id DESC LIMIT 1", (conversation_id,))
            row = cursor.fetchone()
            if row and row["filename"]:
                active = row["filename"]
                cursor.execute("UPDATE conversations SET active_document = ? WHERE id = ?", (active, conversation_id))
                conn.commit()
                return active

            return None

    def get_document_by_id(self, document_id: Optional[str]) -> Optional[Dict[str, Any]]:
        if not document_id:
            return None
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT id, filename, filepath, conversation_id, created_at FROM documents WHERE id = ?", (document_id,))
            row = cursor.fetchone()
            if row:
                return dict(row)
            return None

    def add_message(self, conversation_id: str, role: str, content: str, metadata: Optional[Dict[str, Any]] = None) -> str:
        msg_id = str(uuid.uuid4())
        meta_str = json.dumps(metadata or {})
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                "INSERT INTO messages (id, conversation_id, role, content, metadata_json) VALUES (?, ?, ?, ?, ?)",
                (msg_id, conversation_id, role, content, meta_str)
            )
            conn.commit()
        return msg_id

    def get_conversation_history(self, conversation_id: str, limit: int = 10) -> List[Dict[str, str]]:
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                "SELECT role, content FROM messages WHERE conversation_id = ? ORDER BY created_at ASC LIMIT ?",
                (conversation_id, limit)
            )
            rows = cursor.fetchall()
            return [{"role": r["role"], "content": r["content"]} for r in rows]

    # --- Long-Term Memory Tools & API ---

    def save_memory(self, content: str, category: str = "user_fact") -> int:
        if not content or not content.strip():
            return -1

        content_lower = content.lower()
        
        # Bug 3 Guard & Safety/Privacy: Block System Prompts, Developer Instructions, API Keys, Passwords, or Secrets
        sensitive_keywords = [
            "sk-", "bearer ", "ghp_", "api_key", "apikey", "password", "secret", "pwd=",
            "you are a", "planner", "user query:", "available tools:", "rules:",
            "intent category:", "evaluation criteria:", "system prompt", "plan reasoning:",
            "rag context:", "short-term history:", "retry feedback:", "instructions:",
            "categories:", "synthesizing a final answer", "objective self-evaluation",
            "calculator(expression:", "knowledge_search(", "memory_search(", "memory_save("
        ]
        if any(kw in content_lower for kw in sensitive_keywords):
            logger.warning(f"Blocked attempt to store sensitive info/system prompt as user memory: '{content[:80]}...'")
            return -1

        # Clean user phrasing (e.g., "Remember that my favorite language is Python" -> "My favorite language is Python")
        cleaned_content = content.strip()
        for prefix in [
            "remember that ", "remember my ", "remember ", "store that ", "store my ",
            "save that ", "save my ", "please remember ", "note that "
        ]:
            if cleaned_content.lower().startswith(prefix):
                cleaned_content = cleaned_content[len(prefix):].strip()
                if cleaned_content:
                    cleaned_content = cleaned_content[0].upper() + cleaned_content[1:]
                break

        # Remove trailing period or extra punctuation for normalized comparison
        norm_text = re.sub(r"[^\w\s]", "", cleaned_content.lower()).strip()

        with self._get_connection() as conn:
            cursor = conn.cursor()
            
            # 1. Check for Exact Match Deduplication (case-insensitive & punctuation-insensitive)
            cursor.execute("SELECT id, content FROM memories")
            all_rows = cursor.fetchall()
            for row in all_rows:
                existing_norm = re.sub(r"[^\w\s]", "", row["content"].lower()).strip()
                if existing_norm == norm_text:
                    logger.info(f"Deduplicated identical user memory (ID {row['id']}): '{cleaned_content}'")
                    return row["id"]

            # 2. Check for Topic Match & Upsert/Update (e.g. favorite programming language, favorite color, city, name)
            topic_groups = [
                ["favorite", "language"],
                ["favorite", "programming"],
                ["favorite", "color"],
                ["favorite", "food"],
                ["favorite", "framework"],
                ["favorite", "movie"],
                ["name"],
                ["job"],
                ["role"],
                ["city"],
                ["location"],
                ["live"],
                ["age"]
            ]
            
            for tg in topic_groups:
                if all(term in norm_text for term in tg):
                    for row in all_rows:
                        ex_norm = re.sub(r"[^\w\s]", "", row["content"].lower()).strip()
                        if all(term in ex_norm for term in tg):
                            cursor.execute(
                                "UPDATE memories SET content = ?, category = ?, created_at = CURRENT_TIMESTAMP WHERE id = ?",
                                (cleaned_content, category, row["id"])
                            )
                            conn.commit()
                            logger.info(f"Upserted updated memory for topic {tg} (ID {row['id']}): '{cleaned_content}'")
                            return row["id"]

            # 3. Normal Insert
            cursor.execute("INSERT INTO memories (content, category) VALUES (?, ?)", (cleaned_content, category))
            conn.commit()
            mem_id = cursor.lastrowid
            logger.info(f"Saved memory [{category}] (ID {mem_id}): {cleaned_content}")
            return mem_id

    def save_memory_tool(self, content: str, category: str = "user_fact") -> ToolResult:
        try:
            mem_id = self.save_memory(content, category)
            if mem_id == -1:
                return ToolResult(
                    tool_name="memory_save",
                    success=False,
                    output="",
                    error="Internal system prompts or sensitive secrets cannot be saved as memories."
                )
            return ToolResult(
                tool_name="memory_save",
                success=True,
                output=f"Successfully remembered user fact (ID {mem_id}): '{content}'"
            )
        except Exception as e:
            return ToolResult(tool_name="memory_save", success=False, output="", error=str(e))

    def search_memories(self, query: str, limit: int = 5) -> List[MemoryItem]:
        if not query or not query.strip():
            return []

        # Remove punctuation and extract keywords
        clean_query = re.sub(r"[^\w\s]", "", query).strip()
        query_words = [w.lower() for w in clean_query.split() if len(w) > 2]
        stop_words = {
            "what", "whats", "where", "when", "which", "who", "whom", "whose", "why", "how",
            "is", "are", "was", "were", "do", "does", "did", "my", "your", "his", "her",
            "the", "a", "an", "that", "this", "tell", "remember", "recall", "stored", "say",
            "know", "preference", "fact"
        }
        keywords = [w for w in query_words if w not in stop_words]

        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT id, content, category, created_at FROM memories ORDER BY id DESC")
            rows = cursor.fetchall()
            if not rows:
                return []

            matched_memories = []

            # 1. All keywords match in content
            if keywords:
                for r in rows:
                    ex_norm = re.sub(r"[^\w\s]", "", r["content"].lower()).strip()
                    if all(kw in ex_norm for kw in keywords):
                        matched_memories.append(r)

            # 2. Majority subset keywords match (if >= 2 keywords)
            if not matched_memories and len(keywords) >= 2:
                for r in rows:
                    ex_norm = re.sub(r"[^\w\s]", "", r["content"].lower()).strip()
                    match_count = sum(1 for kw in keywords if kw in ex_norm)
                    if match_count >= 2:
                        matched_memories.append(r)

            # 3. Single keyword fallback if 1 keyword
            if not matched_memories and len(keywords) == 1:
                kw = keywords[0]
                for r in rows:
                    ex_norm = re.sub(r"[^\w\s]", "", r["content"].lower()).strip()
                    if kw in ex_norm:
                        matched_memories.append(r)

            return [
                MemoryItem(
                    id=r["id"],
                    content=r["content"],
                    category=r["category"],
                    created_at=str(r["created_at"])
                )
                for r in matched_memories[:limit]
            ]

    def search_memories_tool(self, query: str) -> ToolResult:
        try:
            items = self.search_memories(query)
            if not items:
                return ToolResult(tool_name="memory_search", success=True, output="No matching long-term memories found.")
            
            formatted = "\n".join([f"- [{m.category}] {m.content}" for m in items])
            return ToolResult(tool_name="memory_search", success=True, output=f"Retrieved Memories:\n{formatted}")
        except Exception as e:
            return ToolResult(tool_name="memory_search", success=False, output="", error=str(e))

    def list_all_memories(self) -> List[MemoryItem]:
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT id, content, category, created_at FROM memories ORDER BY id DESC")
            rows = cursor.fetchall()
            return [
                MemoryItem(id=r["id"], content=r["content"], category=r["category"], created_at=str(r["created_at"]))
                for r in rows
            ]

    # --- Self-Evaluation & User Feedback ---

    def save_evaluation(self, message_id: str, eval_res: Any):
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                """
                INSERT INTO evaluations (message_id, relevance, correctness, completeness, score, status, feedback)
                VALUES (?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    message_id,
                    getattr(eval_res, "relevance_score", 0),
                    getattr(eval_res, "correctness_score", 0),
                    getattr(eval_res, "completeness_score", 0),
                    getattr(eval_res, "total_score", 0),
                    getattr(eval_res, "status", "PASS"),
                    getattr(eval_res, "improvement_feedback", "")
                )
            )
            conn.commit()

    def record_user_feedback(self, message_id: str, is_helpful: bool, comment: Optional[str] = None):
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                "INSERT INTO user_feedback (message_id, is_helpful, comment) VALUES (?, ?, ?)",
                (message_id, is_helpful, comment or "")
            )
            conn.commit()

            # Find corresponding user query from conversation messages
            cursor.execute(
                """
                SELECT content FROM messages 
                WHERE conversation_id = (SELECT conversation_id FROM messages WHERE id = ?) 
                  AND role = 'user' 
                ORDER BY created_at DESC LIMIT 1
                """,
                (message_id,)
            )
            user_msg = cursor.fetchone()
            if user_msg and user_msg["content"]:
                cursor.execute(
                    """
                    UPDATE learning_experiences 
                    SET user_feedback = ?, feedback_comment = ? 
                    WHERE LOWER(TRIM(user_query)) = LOWER(TRIM(?))
                    """,
                    (is_helpful, comment or "", user_msg["content"])
                )
                conn.commit()
            else:
                cursor.execute(
                    """
                    UPDATE learning_experiences 
                    SET user_feedback = ?, feedback_comment = ? 
                    WHERE user_query IN (SELECT content FROM messages WHERE id = ?)
                    """,
                    (is_helpful, comment or "", message_id)
                )
                conn.commit()
            logger.info(f"Recorded user feedback for message {message_id}: Helpful={is_helpful}, Comment={comment}")

    # --- Self-Learning Memory ---

    def record_learning_experience(
        self,
        task_type: str,
        user_query: str,
        approach_summary: str,
        tools_used: List[str],
        score: int,
        user_feedback: Optional[bool] = None,
        feedback_comment: Optional[str] = None,
        success: bool = True
    ):
        with self._get_connection() as conn:
            cursor = conn.cursor()
            
            # Duplicate prevention for identical user query & task_type
            cursor.execute(
                "SELECT id, user_feedback, feedback_comment FROM learning_experiences WHERE LOWER(TRIM(user_query)) = LOWER(TRIM(?)) AND task_type = ? ORDER BY id DESC LIMIT 1",
                (user_query, task_type)
            )
            existing = cursor.fetchone()
            if existing:
                fb = user_feedback if user_feedback is not None else existing["user_feedback"]
                fc = feedback_comment if feedback_comment is not None else existing["feedback_comment"]
                cursor.execute(
                    """
                    UPDATE learning_experiences 
                    SET approach_summary = ?, tools_used = ?, score = ?, user_feedback = ?, feedback_comment = ?, success = ?, created_at = CURRENT_TIMESTAMP
                    WHERE id = ?
                    """,
                    (approach_summary, json.dumps(tools_used), score, fb, fc, success, existing["id"])
                )
                conn.commit()
                logger.info(f"Updated existing Learning Experience (ID {existing['id']}): Task={task_type}, Score={score}")
                return existing["id"]

            cursor.execute(
                """
                INSERT INTO learning_experiences 
                (task_type, user_query, approach_summary, tools_used, score, user_feedback, feedback_comment, success)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    task_type,
                    user_query,
                    approach_summary,
                    json.dumps(tools_used),
                    score,
                    user_feedback,
                    feedback_comment,
                    success
                )
            )
            conn.commit()
            mem_id = cursor.lastrowid
            logger.info(f"Recorded Learning Experience: Task={task_type}, Score={score}, Success={success}")
            return mem_id

    def get_relevant_learning_experiences(self, query: str, task_type: str, limit: int = 3) -> List[LearningExperience]:
        """Retrieve relevant past problem-solving attempts to inject wisdom/hints into future plans."""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            query_clean = re.sub(r"[^\w\s]", "", query.lower()).strip() if query else ""
            query_words = [w for w in query_clean.split() if len(w) > 3]

            cursor.execute(
                """
                SELECT id, task_type, user_query, approach_summary, tools_used, score, user_feedback, feedback_comment, success, created_at
                FROM learning_experiences
                ORDER BY created_at DESC
                """
            )
            rows = cursor.fetchall()
            
            experiences = []
            for r in rows:
                row_query = re.sub(r"[^\w\s]", "", r["user_query"].lower()).strip()
                is_task_match = (r["task_type"] == task_type)
                is_overlap = any(w in row_query for w in query_words) if query_words else False
                is_expl_query = any(kw in query_clean for kw in ["explain", "how", "what", "guide", "tutorial"]) and any(kw in row_query for kw in ["explain", "how", "what", "guide", "tutorial"])

                if not query or is_task_match or is_overlap or is_expl_query:
                    tools = []
                    try:
                        tools = json.loads(r["tools_used"])
                    except Exception:
                        tools = []

                    fb_val = bool(r["user_feedback"]) if r["user_feedback"] is not None else None
                    fb_comment = r["feedback_comment"] if "feedback_comment" in r.keys() and r["feedback_comment"] else None

                    experiences.append(LearningExperience(
                        id=r["id"],
                        task_type=r["task_type"],
                        user_query=r["user_query"],
                        approach_summary=r["approach_summary"],
                        tools_used=tools,
                        score=r["score"],
                        user_feedback=fb_val,
                        feedback_comment=fb_comment,
                        success=bool(r["success"]),
                        created_at=str(r["created_at"])
                    ))
            
            # Prioritize experiences that have explicit negative feedback + user guidance first, then positive feedback, then score
            experiences.sort(
                key=lambda x: (
                    0 if (x.user_feedback is False and x.feedback_comment) else (1 if x.user_feedback is False else (2 if x.user_feedback is True else 3)),
                    -x.score
                )
            )

            return experiences[:limit]

memory_db = MemoryDatabase()
