# Self-Learning AI Agent — 5 to 7 Minute Placement Demonstration Guide

This reproducible demo script is designed for live portfolio reviews, placement presentations, and technical interviews.

---

## ⏱️ Live Demo Sequence Outline (Total Time: ~6 Minutes)

| Step | Time | Action | Demonstration Highlight |
|---|---|---|---|
| 1 | 0:00 - 0:30 | Launch Dashboard & Status | System Architecture & Provider Config |
| 2 | 0:30 - 1:15 | General Knowledge Query | Agent Reasoning & Self-Evaluation Audit |
| 3 | 1:15 - 2:00 | RAG Document Ingestion | Document Chunking & Active Document Vector Search |
| 4 | 2:00 - 3:00 | Negative Feedback Submission | User Guidance Capture & Database Experience Storage |
| 5 | 3:00 - 4:15 | Cross-Conversation Adaptation | Self-Learning Memory Retrieval & Adapted Strategy Execution |
| 6 | 4:15 - 5:00 | Calculator Tool Execution | AST Safe Tool Execution & Context Minimization |
| 7 | 5:00 - 6:00 | Inspector & Architecture Recap | Database Persistence Audit & Production Design |

---

## 🎭 Step-by-Step Script & Talk Track

### Step 1: System Launch & Control Center Setup (0:00 - 0:30)
- **Action**: Open terminal and launch Streamlit UI:
  ```powershell
  .venv\Scripts\streamlit run frontend/app.py
  ```
- **Talk Track**:
  > *"Welcome! Today I am demonstrating a framework-free Self-Learning AI Agent built from scratch in Python, FastAPI, Streamlit, and SQLite. Unlike generic wrapper chatbots that forget user preferences between sessions, this system implements goal planning, isolated context minimization, vector RAG retrieval, safe tool calling, self-evaluation monitoring, and cross-conversation experience learning."*
- **Visual Highlight**: Point to the **Sidebar Control Center** showing System Status (`Provider`, `API Key Status`, `Knowledge Base`).

---

### Step 2: General Knowledge & Self-Evaluation Monitor (0:30 - 1:15)
- **Action**: Enter query in chat input:
  ```text
  Explain recursion to a beginner.
  ```
- **Talk Track**:
  > *"When a prompt is submitted, the agent planner first classifies the intent as GENERAL_KNOWLEDGE. It chooses not to pull unnecessary documents or run irrelevant tools, keeping context minimal. Notice the real-time Activity Trace panel tracking each phase from understanding to planning to evaluation."*
- **Visual Highlight**:
  - Open the **📊 Execution Traces & Self-Evaluation Details** expander.
  - Show the **Self-Evaluation Accordion** metrics (`Relevance: 9/10`, `Correctness: 9/10`, `Completeness: 9/10`, `Total Score: 90/100`, `Status: PASS`).

---

### Step 3: RAG Knowledge Ingestion & Document Lookup (1:15 - 2:00)
- **Action**:
  1. In the sidebar under **📄 Knowledge Base RAG**, upload `sample_document.pdf` (or `.txt`).
  2. Click **Index Document**.
  3. Ask in chat:
     ```text
     What are the core technical specifications mentioned in the document?
     ```
- **Talk Track**:
  > *"The agent detects a DOCUMENT_QUESTION intent and invokes the knowledge_search RAG tool. Text is chunked, embedded into normalized vectors, and indexed into SQLite with active document session isolation."*
- **Visual Highlight**: Show the **Retrieved Context** tab displaying the exact grounded document text chunks used for answer synthesis.

---

### Step 4: Submitting Feedback & Experience Recording (2:00 - 3:00)
- **Action**: On the response generated for recursion, click **👎 Not Helpful** and enter comment:
  ```text
  Too complicated. Use a very simple real-world analogy and explain it step by step.
  ```
- **Talk Track**:
  > *"Now we trigger the self-learning feedback loop. When I rate a response as unhelpful with feedback, the system updates the learning_experiences record in SQLite. It preserves the explicit user guidance lesson without modifying neural network weights."*
- **Visual Highlight**: Toast notification confirming feedback recording.

---

### Step 5: Cross-Conversation Strategy Adaptation (3:00 - 4:15)
- **Action**:
  1. Click **Clear Conversation** in the sidebar to start a fresh session (or change conversation ID).
  2. Ask a related query:
     ```text
     Explain binary search to me.
     ```
- **Talk Track**:
  > *"Now watch the magic of self-learning across conversations! In this new session, the agent planner queries past problem-solving experiences. It retrieves the prior lesson from our recursion query, detects that the user prefers simple real-world analogies, and dynamically adapts its strategy."*
- **Visual Highlight**:
  - Point to the Activity Trace steps: `Retrieved relevant learning experience` → `Adapted strategy`.
  - Show that the generated response uses a real-world dictionary/phonebook analogy as requested by past feedback.

---

### Step 6: Tool Execution & Context Minimization (4:15 - 5:00)
- **Action**: Enter calculation query:
  ```text
  Calculate 125 * 24 and explain the result simply.
  ```
- **Talk Track**:
  > *"For mathematical tasks, the planner isolates the CALCULATION intent and triggers the safe calculator tool built with Python AST parsing. This prevents code execution vulnerabilities while delivering exact numerical accuracy."*
- **Visual Highlight**: Show `calculator` listed under **Tools Used** and output `3000`.

---

### Step 7: Inspector Tab & Architecture Wrap-Up (5:00 - 6:00)
- **Action**: In sidebar under **🔍 Memory & Learning Inspector**, click **Learned Experiences**.
- **Talk Track**:
  > *"To summarize: all memories and experiences persist across API restarts in SQLite. We have verified zero prompt leakage, 100% test coverage across 69 test cases, and a complete self-learning loop. Thank you!"*
