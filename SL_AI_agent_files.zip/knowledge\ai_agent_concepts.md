# Practical AI Agent Architecture Guide (Dave Ebbelaar Concepts)

## Core Concept
An AI Agent is a system that combines a Large Language Model (LLM) with planning, tool usage, memory, RAG, and self-evaluation to achieve specific goals autonomously.

## 1. LLM Brain & Structured Outputs
The LLM acts as the decision-making engine. Rather than generating unconstrained text, effective agents return structured Pydantic objects or JSON specifying target intents and tool call parameters.

## 2. Tools & Actions
Tools give the LLM the ability to interact with the environment:
- Calculator for math
- RAG search for custom document retrieval
- Long-term memory storage for user facts
- Web search for real-time information

## 3. RAG (Retrieval-Augmented Generation)
RAG indexes user documents (PDF, TXT, MD) by splitting text into overlapping chunks, generating vector embeddings, and retrieving top relevant chunks during query synthesis.

## 4. Self-Evaluation & Self-Improvement
After generating an initial response, the agent evaluates its own output across relevance, correctness, completeness, and task completion. If the score is below the threshold, the agent modifies its approach and retries.

## 5. Feedback-Based Self-Learning
User feedback (thumbs up / thumbs down) and past problem-solving attempts are saved into a SQLite database. Before planning new tasks, the agent inspects past experiences to apply lessons learned.
