# Self-Learning AI Agent — System Architecture Documentation

This document describes the internal design, component responsibilities, data flow, and self-learning mechanics of the production-quality **Self-Learning AI Agent** framework.

---

## 🏗️ High-Level System Architecture

```
                                  ┌───────────────────────────┐
                                  │   Streamlit Web UI /      │
                                  │   FastAPI REST API        │
                                  └─────────────┬─────────────┘
                                                │
                                                ▼
                                  ┌───────────────────────────┐
                                  │    SelfLearningAgent      │
                                  │      (Execution Loop)     │
                                  └─────────────┬─────────────┘
                                                │
                 ┌──────────────────────────────┼──────────────────────────────┐
                 ▼                              ▼                              ▼
    ┌───────────────────────────┐ ┌───────────────────────────┐ ┌───────────────────────────┐
    │       AgentPlanner        │ │     SQLite Memory DB      │ │        RAGEngine          │
    │  (Understand & Intent)    │ │ (Short/Long-Term & Exper.)│ │ (Vector Search & Chunking)│
    └────────────┬──────────────┘ └─────────────┬─────────────┘ └─────────────┬─────────────┘
                 │                              │                              │
                 └──────────────────────────────┼──────────────────────────────┘
                                                │
                                                ▼
                                  ┌───────────────────────────┐
                                  │      LLMClient & Tools    │
                                  │ (Synthesis & Safe Calc)   │
                                  └─────────────┬─────────────┘
                                                │
                                                ▼
                                  ┌───────────────────────────┐
                                  │      AgentEvaluator       │
                                  │ (Self-Evaluation Monitor) │
                                  └─────────────┬─────────────┘
                                                │
                                                ▼
                                  ┌───────────────────────────┐
                                  │      FeedbackHandler      │
                                  │ (Thumbs Up/Down & Lessons)│
                                  └───────────────────────────┘
```

---

## 🧩 Component Breakdown

### 1. Agent Engine (`app/agent.py`)
- **Class**: `SelfLearningAgent`
- **Role**: Core orchestration engine managing execution cycles.
- **Workflow**:
  1. Retrieves short-term chat history for context minimization.
  2. Calls `AgentPlanner.plan()` to classify intent, query long-term memory/past learning experiences, and select minimal tools.
  3. Executes selected tools concurrently (e.g. calculator, vector search).
  4. Calls `LLMClient.generate_text()` to synthesize answers grounded strictly in retrieved context.
  5. Triggers `AgentEvaluator.evaluate()` to check response relevance, correctness, completeness, and context grounding.
  6. Automatically retries if evaluation score falls below threshold (`70/100`).
  7. Records final step as `Completed` and saves assistant messages & learning experience records into SQLite database.

### 2. Agent Planner (`app/planner.py`)
- **Class**: `AgentPlanner`
- **Role**: Intent router, tool selection engine, and past lesson strategy adapter.
- **Intent Categories**:
  - `GENERAL_KNOWLEDGE`: Reasoning, standard knowledge questions, or coding.
  - `CALCULATION`: Explicit or implicit math expressions.
  - `DOCUMENT_QUESTION`: Question regarding uploaded PDF/Markdown/Text document.
  - `DOCUMENT_SUMMARY`: Document narration or high-level overview.
  - `MEMORY_QUERY` / `MEMORY_SAVE`: Long-term user fact search or storage.
  - `IMAGE_QUESTION`: Screenshot or photo analysis requests.
  - `NORMAL_CHAT`: Conversational greetings.
- **Strategy Adaptation**: Queries past problem-solving experiences (`memory_db.get_relevant_learning_experiences()`). If negative user feedback exists for matching task patterns, injects `CRITICAL USER LESSON` into the planner context and adapts reasoning strategy.

### 3. LLM Client & Synthesizer (`app/llm.py`)
- **Class**: `LLMClient`
- **Role**: Multi-provider LLM interface supporting OpenAI API format (OpenAI, Gemini, Groq) with automatic offline rule-based fallback mode.
- **Output Sanitization**: Includes `sanitize_answer()` to strip internal system instructions, prompt headers, and sensitive key patterns from answers.

### 4. Memory Database (`app/memory.py`)
- **Class**: `MemoryDatabase`
- **Storage Layer**: SQLite (`data/agent.db`).
- **Sub-systems**:
  - **Short-Term Memory**: Conversation sessions, title metadata, and message logs.
  - **Long-Term Memory**: User facts and preferences with deduplication and in-place update logic.
  - **Evaluation Storage**: Audit logs of evaluator metrics (`relevance`, `correctness`, `completeness`, `total_score`).
  - **User Feedback**: Thumbs up/down ratings and custom feedback strings.
  - **Self-Learning Memory**: Experience records (`learning_experiences` table) storing task type, approach summary, tools used, score, and user guidance comments.

### 5. Knowledge RAG Engine (`app/rag.py`)
- **Class**: `RAGEngine`
- **Role**: Ingests PDF, TXT, and Markdown files, splits text into overlapping chunks, computes normalized TF-IDF / vector embeddings, and executes cosine similarity searches.
- **Active Document Isolation**: Restricts document searches strictly to the active document bound to the current conversation session.

### 6. Tools & Safe Calculator (`app/tools.py`)
- **Class**: `SafeCalculator`, `ToolRegistry`
- **Role**: Secure mathematical expression evaluation using Python AST parsing (blocking `eval` security vulnerabilities).
- **Available Tools**: `calculator`, `knowledge_search`, `memory_search`, `memory_save`, `file_reader`, `web_search`.

### 7. Self-Evaluator Monitor (`app/evaluator.py`)
- **Class**: `AgentEvaluator`
- **Role**: Performs self-evaluations against relevance, correctness, completeness, and context grounding. Returns structured `EvaluationResult` containing numeric scores (`0-100`), status (`PASS` or `RETRY`), and improvement feedback.

### 8. Feedback Handler (`app/feedback.py`)
- **Class**: `FeedbackHandler`
- **Role**: Accepts user ratings and updates learning experience records in SQLite, closing the self-learning loop.

### 9. REST API Service (`api/routes.py`, `main.py`)
- **Framework**: FastAPI with Uvicorn server.
- **Endpoints**: `/chat`, `/feedback`, `/documents`, `/memory`, `/logs`, `/health`.

### 10. Web Interface (`frontend/app.py`)
- **Framework**: Streamlit.
- **Features**: Real-time activity trace panel, dynamic tool output accordions, interactive feedback buttons, and memory/learning experience inspector tabs.

---

## 🔄 Self-Learning Loop Sequence

```
[ User Prompt ]
       │
       ▼
[ Planner Intent Router ] ──► Queries [ Learning Experiences DB ]
       │                                     │
       ▼                                     ▼
[ Formulate Plan ] ◄────── Injects Past Negative Feedback Lesson
       │
       ▼
[ Minimal Tool / RAG Execution ]
       │
       ▼
[ Grounded Answer Synthesis ]
       │
       ▼
[ Self-Evaluation Monitor ] ──► Total Score < 70? ──► [ Retry Execution ]
       │ Score >= 70
       ▼
[ Display Response & Record Experience ]
       │
       ▼
[ User Submits Thumbs Up/Down & Comment ]
       │
       ▼
[ Update Learning Experience Record ] ──► Applied in Future Conversations
```
