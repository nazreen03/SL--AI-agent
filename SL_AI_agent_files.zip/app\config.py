import os
from pathlib import Path
from dotenv import load_dotenv

# Load .env file if available
BASE_DIR = Path(__file__).resolve().parent.parent
dotenv_path = BASE_DIR / ".env"
if dotenv_path.exists():
    load_dotenv(dotenv_path)

class Settings:
    PROJECT_NAME: str = "Self-Learning AI Agent"
    VERSION: str = "1.0.0"
    BASE_DIR: Path = BASE_DIR

    def reload_env(self):
        if dotenv_path.exists():
            load_dotenv(dotenv_path, override=True)

    # LLM Settings
    @property
    def LLM_PROVIDER(self) -> str:
        self.reload_env()
        return os.getenv("LLM_PROVIDER", "mock").lower()

    @property
    def OPENAI_API_KEY(self) -> str:
        self.reload_env()
        return os.getenv("OPENAI_API_KEY", "")

    @property
    def OPENAI_MODEL(self) -> str:
        return os.getenv("OPENAI_MODEL", "gpt-4o-mini")

    @property
    def OPENAI_BASE_URL(self) -> str:
        return os.getenv("OPENAI_BASE_URL", "https://api.openai.com/v1")
    
    # Database and Logs
    @property
    def DB_PATH(self) -> Path:
        return BASE_DIR / os.getenv("DB_PATH", "data/agent.db")

    @property
    def LOG_PATH(self) -> Path:
        return BASE_DIR / os.getenv("LOG_PATH", "logs/agent.log")

    @property
    def KNOWLEDGE_DIR(self) -> Path:
        return BASE_DIR / os.getenv("KNOWLEDGE_DIR", "knowledge")
    
    # Agent Tuning
    @property
    def MAX_RETRY_ATTEMPTS(self) -> int:
        try:
            return int(os.getenv("MAX_RETRY_ATTEMPTS", "3"))
        except ValueError:
            return 3

    @property
    def EVALUATION_PASS_SCORE(self) -> int:
        try:
            return int(os.getenv("EVALUATION_PASS_SCORE", "70"))
        except ValueError:
            return 70

    @property
    def EMBEDDING_MODEL(self) -> str:
        return os.getenv("EMBEDDING_MODEL", "text-embedding-3-small")

    @property
    def is_api_key_configured(self) -> bool:
        key = self.OPENAI_API_KEY.strip()
        invalid_placeholders = ["", "your_openai_api_key_here", "sk-your-openai-key-here", "sk-proj-your_key_here"]
        return bool(key and key not in invalid_placeholders)

settings = Settings()

# Ensure directories exist
settings.DB_PATH.parent.mkdir(parents=True, exist_ok=True)
settings.LOG_PATH.parent.mkdir(parents=True, exist_ok=True)
settings.KNOWLEDGE_DIR.mkdir(parents=True, exist_ok=True)
