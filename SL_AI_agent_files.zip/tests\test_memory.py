import pytest
from app.memory import MemoryDatabase
from pathlib import Path
import tempfile
import os

@pytest.fixture
def temp_memory_db():
    with tempfile.NamedTemporaryFile(suffix=".db", delete=False) as f:
        db_path = Path(f.name)
    db = MemoryDatabase(db_path=db_path)
    yield db
    try:
        if db_path.exists():
            os.remove(db_path)
    except Exception:
        pass


def test_conversation_and_messages(temp_memory_db):
    conv_id = temp_memory_db.ensure_conversation()
    assert conv_id is not None
    
    msg_id = temp_memory_db.add_message(conv_id, "user", "Hello world")
    assert msg_id is not None
    
    history = temp_memory_db.get_conversation_history(conv_id)
    assert len(history) == 1
    assert history[0]["content"] == "Hello world"

def test_long_term_memory_save_and_search(temp_memory_db):
    temp_memory_db.save_memory("Favorite programming language is Python", category="user_fact")
    temp_memory_db.save_memory("Prefers dark mode UI", category="user_preference")
    
    results = temp_memory_db.search_memories("Python")
    assert len(results) >= 1
    assert "Python" in results[0].content

def test_learning_experiences(temp_memory_db):
    temp_memory_db.record_learning_experience(
        task_type="CALCULATION",
        user_query="Calculate 50 * 20",
        approach_summary="Used calculator tool",
        tools_used=["calculator"],
        score=95,
        user_feedback=True,
        success=True
    )
    
    exps = temp_memory_db.get_relevant_learning_experiences("Calculate", "CALCULATION")
    assert len(exps) >= 1
    assert exps[0].score == 95
    assert exps[0].success is True

def test_active_document_id_persistence(temp_memory_db):
    conv_id = temp_memory_db.ensure_conversation()
    doc_id = "doc-uuid-1234-5678"
    filename = "test_resume.pdf"
    
    temp_memory_db.save_document(doc_id, filename, "/path/to/test_resume.pdf", conv_id)
    temp_memory_db.set_active_document_id(conv_id, doc_id)
    
    retrieved_id = temp_memory_db.get_active_document_id(conv_id)
    assert retrieved_id == doc_id
    
    retrieved_doc = temp_memory_db.get_document_by_id(doc_id)
    assert retrieved_doc is not None
    assert retrieved_doc["filename"] == filename
    assert retrieved_doc["conversation_id"] == conv_id
