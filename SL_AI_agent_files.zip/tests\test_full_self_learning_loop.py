import pytest
import asyncio
import tempfile
import os
from pathlib import Path

from app.schemas import ChatRequest, IntentCategory
from app.memory import memory_db, MemoryDatabase
from app.agent import agent
from app.planner import planner
from app.rag import rag_engine
from app.llm import llm_client

def test_1_task_response_evaluation():
    with memory_db._get_connection() as conn:
        conn.cursor().execute("DELETE FROM learning_experiences")
        conn.cursor().execute("DELETE FROM user_feedback")
        conn.commit()

    req = ChatRequest(query="Explain recursion to a beginner.", conversation_id="conv-p5-1")
    res = asyncio.run(agent.run(req))
    
    assert res.message_id is not None
    assert res.answer is not None
    assert res.evaluation is not None
    assert res.evaluation.total_score >= 70
    assert res.evaluation.status == "PASS"

def test_2_negative_feedback_learning():
    req = ChatRequest(query="Explain recursion to a beginner.", conversation_id="conv-p5-2")
    res = asyncio.run(agent.run(req))
    
    memory_db.record_user_feedback(
        message_id=res.message_id,
        is_helpful=False,
        comment="Too complicated. Use a very simple real-world analogy and explain it step by step."
    )
    
    exps = memory_db.get_relevant_learning_experiences("recursion", "GENERAL_KNOWLEDGE")
    assert len(exps) >= 1
    assert exps[0].user_feedback is False
    assert exps[0].feedback_comment == "Too complicated. Use a very simple real-world analogy and explain it step by step."

def test_3_learning_experience_retrieval():
    exps = memory_db.get_relevant_learning_experiences("Explain binary search to me", "GENERAL_KNOWLEDGE")
    assert len(exps) >= 1
    assert exps[0].feedback_comment is not None
    assert "real-world analogy" in exps[0].feedback_comment

def test_4_planner_strategy_adaptation():
    plan = planner.plan("Explain binary search to me.", chat_history=[])
    assert plan.past_experience_hint is not None
    assert "CRITICAL USER LESSON" in plan.past_experience_hint
    assert "Adapted strategy" in plan.reasoning_summary or "lesson" in plan.reasoning_summary.lower()

def test_5_cross_conversation_learning():
    req = ChatRequest(query="Explain binary search to me.", conversation_id="conv-p5-new-session")
    res = asyncio.run(agent.run(req))
    
    step_names = [s.step_name for s in res.steps]
    assert "Retrieved relevant learning experience" in step_names
    assert "Adapted strategy" in step_names
    
    answer_lower = res.answer.lower()
    assert any(kw in answer_lower for kw in ["dictionary", "phonebook", "middle", "analog", "doll", "page"])

def test_6_rag_and_feedback_adaptation(tmp_path):
    doc_path = tmp_path / "test_sample_kb.txt"
    doc_path.write_text(
        "Segment-IQ AI platform provides real-time analytics, automated data pipeline processing, "
        "and multi-tenant vector index retrieval with sub-millisecond response latency.",
        encoding="utf-8"
    )
    
    conv_id = "conv-rag-p5-1"
    chunks, msg = rag_engine.ingest_file(doc_path, conversation_id=conv_id)
    assert chunks > 0
    
    req1 = ChatRequest(query="What does Segment-IQ platform provide?", conversation_id=conv_id)
    res1 = asyncio.run(agent.run(req1))
    assert "analytics" in res1.answer.lower() or "segment-iq" in res1.answer.lower() or "provides" in res1.answer.lower()
    
    # User submits negative feedback asking for concise summary
    memory_db.record_user_feedback(
        message_id=res1.message_id,
        is_helpful=False,
        comment="The answer is too detailed. Give me a shorter explanation with the important points only."
    )
    
    # New conversation asking about the document
    conv_id2 = "conv-rag-p5-2"
    memory_db.set_active_document_id(conv_id2, memory_db.get_active_document_id(conv_id))
    
    req2 = ChatRequest(query="Summarize what Segment-IQ provides.", conversation_id=conv_id2)
    res2 = asyncio.run(agent.run(req2))
    
    assert res2.answer is not None
    assert len(res2.answer) > 0
    step_names = [s.step_name for s in res2.steps]
    assert "Understanding request" in step_names
    assert "Planning" in step_names
    assert "Generating answer" in step_names
    assert "Evaluating response" in step_names
    assert "Completed" in step_names

def test_7_tool_execution_and_evaluation():
    req = ChatRequest(query="Calculate 125 * 24 and explain the result simply.", conversation_id="conv-tool-p5")
    res = asyncio.run(agent.run(req))
    
    assert "calculator" in res.tools_used
    assert "3000" in res.answer
    assert res.evaluation.total_score >= 70
    assert res.evaluation.status == "PASS"

def test_8_evaluator_retry():
    # 1. Direct evaluator failure detection
    from app.evaluator import evaluator
    eval_fail = evaluator.evaluate(
        query="Calculate 2 + 2",
        answer="invalid",
        context="",
        intent=IntentCategory.CALCULATION,
        has_tool_failure=True
    )
    assert eval_fail.status == "RETRY"
    assert eval_fail.total_score == 30
    assert eval_fail.improvement_feedback is not None

    # 2. End-to-End Agent Retry Loop Execution Test
    orig_evaluate = evaluator.evaluate
    eval_count = 0

    def mock_eval_retry(*args, **kwargs):
        nonlocal eval_count
        eval_count += 1
        if eval_count == 1:
            from app.schemas import EvaluationResult
            return EvaluationResult(
                relevance_score=4, correctness_score=3, completeness_score=3,
                total_score=40, status="RETRY", improvement_feedback="Answer lacked detail."
            )
        return orig_evaluate(*args, **kwargs)

    evaluator.evaluate = mock_eval_retry
    try:
        req = ChatRequest(query="Calculate 10 + 10", conversation_id="conv-retry-test")
        res = asyncio.run(agent.run(req))
        assert res.attempts == 2
        step_names = [s.step_name for s in res.steps]
        assert "Self-Improvement Retry" in step_names
        assert res.evaluation.status == "PASS"
    finally:
        evaluator.evaluate = orig_evaluate

def test_9_persistence_after_restart():
    with tempfile.NamedTemporaryFile(suffix=".db", delete=False) as f:
        db_path = Path(f.name)
    
    db1 = MemoryDatabase(db_path=db_path)
    msg_id = db1.add_message("conv-pers-1", "user", "Explain sorting algorithms")
    db1.record_learning_experience(
        task_type="GENERAL_KNOWLEDGE",
        user_query="Explain sorting algorithms",
        approach_summary="Listed algorithms",
        tools_used=[],
        score=80,
        success=True
    )
    db1.record_user_feedback(
        message_id=msg_id,
        is_helpful=False,
        comment="Explain using a simple card deck sorting example."
    )
    
    # Restart API / instantiate new DB on same file
    db2 = MemoryDatabase(db_path=db_path)
    exps = db2.get_relevant_learning_experiences("sorting", "GENERAL_KNOWLEDGE")
    assert len(exps) == 1
    assert exps[0].feedback_comment == "Explain using a simple card deck sorting example."
    
    try:
        os.remove(db_path)
    except Exception:
        pass

def test_10_duplicate_prevention():
    with memory_db._get_connection() as conn:
        conn.cursor().execute("DELETE FROM learning_experiences WHERE user_query = 'Explain recursion to a beginner.'")
        conn.commit()

    id1 = memory_db.record_learning_experience(
        task_type="GENERAL_KNOWLEDGE",
        user_query="Explain recursion to a beginner.",
        approach_summary="First attempt",
        tools_used=[],
        score=75,
        success=True
    )
    id2 = memory_db.record_learning_experience(
        task_type="GENERAL_KNOWLEDGE",
        user_query="Explain recursion to a beginner.",
        approach_summary="Second attempt updated",
        tools_used=[],
        score=95,
        success=True
    )
    assert id1 == id2
    exps = memory_db.get_relevant_learning_experiences("Explain recursion to a beginner.", "GENERAL_KNOWLEDGE")
    matching_exps = [e for e in exps if e.user_query == "Explain recursion to a beginner."]
    assert len(matching_exps) == 1
    assert matching_exps[0].score == 95

def test_11_prompt_leakage_prevention():
    raw_answer = (
        "CRITICAL USER LESSON: User requested simpler explanation.\n"
        "You are a Self-Learning AI Agent Planner...\n"
        "Binary search is an algorithm that finds an element in a sorted list by opening to the middle."
    )
    clean = llm_client.sanitize_answer(raw_answer)
    assert "CRITICAL USER LESSON" not in clean
    assert "You are a Self-Learning AI Agent" not in clean
    assert "Binary search is an algorithm" in clean

def test_12_false_cancellation_prevention():
    req = ChatRequest(query="Define Python", conversation_id="conv-cancel-check")
    res = asyncio.run(agent.run(req))
    
    last_step = res.steps[-1]
    assert last_step.step_name == "Completed"
    assert "User cancelled" not in last_step.description
