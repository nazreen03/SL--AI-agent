import pytest
from fastapi.testclient import TestClient
from api.main import app

client = TestClient(app)

def test_health_endpoint():
    response = client.get("/health")
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "healthy"
    assert "project" in data

def test_chat_endpoint():
    response = client.post("/chat", json={"query": "Calculate 100 / 5"})
    assert response.status_code == 200
    data = response.json()
    assert "answer" in data
    assert "score" in data
    assert "steps" in data

def test_memory_endpoint():
    response = client.get("/memory")
    assert response.status_code == 200
    data = response.json()
    assert "memories" in data
    assert "learning_experiences" in data
