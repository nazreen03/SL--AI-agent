import pytest
from unittest.mock import MagicMock, PropertyMock, patch
from app.llm import LLMClient
from app.config import Settings
from app.schemas import AgentPlan, IntentCategory

def test_llm_client_mock_mode_when_configured():
    client = LLMClient()
    # Force settings to mock
    with patch.object(Settings, "LLM_PROVIDER", new_callable=PropertyMock, return_value="mock"):
        raw_client = client._get_client()
        assert raw_client is None
        text = client.generate_text("Define Python")
        assert "Python" in text

def test_llm_client_real_provider_text_generation():
    client = LLMClient()
    mock_openai_instance = MagicMock()
    mock_response = MagicMock()
    mock_choice = MagicMock()
    mock_choice.message.content = "Machine learning is a field of AI focusing on learning from data."
    mock_response.choices = [mock_choice]
    mock_openai_instance.chat.completions.create.return_value = mock_response

    with patch.object(Settings, "LLM_PROVIDER", new_callable=PropertyMock, return_value="openai"), \
         patch.object(Settings, "is_api_key_configured", new_callable=PropertyMock, return_value=True), \
         patch.object(Settings, "OPENAI_API_KEY", new_callable=PropertyMock, return_value="sk-testkey12345"), \
         patch.object(client, "_get_client", return_value=mock_openai_instance):

        res = client.generate_text("What is machine learning?")
        assert "Machine learning" in res
        mock_openai_instance.chat.completions.create.assert_called_once()

def test_llm_client_structured_generation():
    client = LLMClient()
    mock_openai_instance = MagicMock()
    mock_response = MagicMock()
    mock_choice = MagicMock()
    json_output = '{"query": "What is machine learning?", "intent": "GENERAL_KNOWLEDGE", "reasoning_summary": "General AI question", "context_decision": "No RAG needed", "tools_to_use": [], "requires_rag": false, "requires_memory": false}'
    mock_choice.message.content = f"```json\n{json_output}\n```"
    mock_response.choices = [mock_choice]
    mock_openai_instance.chat.completions.create.return_value = mock_response

    with patch.object(Settings, "LLM_PROVIDER", new_callable=PropertyMock, return_value="openai"), \
         patch.object(Settings, "is_api_key_configured", new_callable=PropertyMock, return_value=True), \
         patch.object(Settings, "OPENAI_API_KEY", new_callable=PropertyMock, return_value="sk-testkey12345"), \
         patch.object(client, "_get_client", return_value=mock_openai_instance):

        plan = client.generate_structured("What is machine learning?", AgentPlan)
        assert isinstance(plan, AgentPlan)
        assert plan.intent == IntentCategory.GENERAL_KNOWLEDGE

def test_llm_client_graceful_invalid_api_key_handling():
    client = LLMClient()
    mock_openai_instance = MagicMock()
    mock_openai_instance.chat.completions.create.side_effect = Exception("401 Invalid API Key")

    with patch.object(Settings, "LLM_PROVIDER", new_callable=PropertyMock, return_value="openai"), \
         patch.object(Settings, "is_api_key_configured", new_callable=PropertyMock, return_value=True), \
         patch.object(Settings, "OPENAI_API_KEY", new_callable=PropertyMock, return_value="sk-invalidkey"), \
         patch.object(client, "_get_client", return_value=mock_openai_instance):

        # Should log invalid API key error and fall back gracefully to mock mode without raising exception
        res = client.generate_text("Hello")
        assert isinstance(res, str)
        assert len(res) > 0

def test_llm_client_graceful_timeout_handling():
    client = LLMClient()
    mock_openai_instance = MagicMock()
    mock_openai_instance.chat.completions.create.side_effect = Exception("APITimeoutError: Request timed out")

    with patch.object(Settings, "LLM_PROVIDER", new_callable=PropertyMock, return_value="openai"), \
         patch.object(Settings, "is_api_key_configured", new_callable=PropertyMock, return_value=True), \
         patch.object(client, "_get_client", return_value=mock_openai_instance):

        res = client.generate_text("Hello")
        assert isinstance(res, str)

def test_llm_client_graceful_rate_limit_handling():
    client = LLMClient()
    mock_openai_instance = MagicMock()
    mock_openai_instance.chat.completions.create.side_effect = Exception("429 RateLimitError: Rate limit exceeded")

    with patch.object(Settings, "LLM_PROVIDER", new_callable=PropertyMock, return_value="openai"), \
         patch.object(Settings, "is_api_key_configured", new_callable=PropertyMock, return_value=True), \
         patch.object(client, "_get_client", return_value=mock_openai_instance):

        res = client.generate_text("Hello")
        assert isinstance(res, str)

