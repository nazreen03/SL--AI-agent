import re
from typing import List, Dict, Any, Optional
from app.schemas import AgentPlan, IntentCategory, ToolCall
from app.llm import llm_client
from app.prompts import PLANNER_PROMPT
from app.memory import memory_db
from app.logger import logger

class AgentPlanner:
    """Agent Planner responsible for understanding goals, selecting tools, and applying past lessons learned."""

    def plan(self, query: str, chat_history: List[Dict[str, str]], conversation_id: Optional[str] = None) -> AgentPlan:
        logger.info(f"Formulating plan for user query: '{query}'")

        # 1. Classify initial intent
        intent = self._classify_intent(query, conversation_id=conversation_id)
        
        # 2. Retrieve past self-learning experience hints & user feedback lessons
        past_experiences = memory_db.get_relevant_learning_experiences(query=query, task_type=intent.value, limit=2)
        past_hint = ""
        if past_experiences:
            hints = []
            for exp in past_experiences:
                if exp.user_feedback is False and exp.feedback_comment:
                    hints.append(
                        f"CRITICAL USER LESSON from past attempt on '{exp.user_query}': User gave NEGATIVE feedback stating: '{exp.feedback_comment}'. "
                        f"ADAPT STRATEGY: Address user feedback directly by using simple, beginner-friendly explanations with real-world analogies/examples."
                    )
                elif exp.user_feedback is True:
                    hints.append(
                        f"PROVEN STRATEGY from past attempt on '{exp.user_query}': User gave POSITIVE feedback. "
                        f"Approach '{exp.approach_summary}' was helpful."
                    )
                else:
                    status_str = "SUCCESS" if exp.success else "FAILED"
                    hints.append(f"Past attempt ({status_str}, Score {exp.score}): Approach '{exp.approach_summary}'.")
            past_hint = "\n".join(hints)

        # 3. Format prompt
        formatted_history = "\n".join([f"{m['role'].capitalize()}: {m['content']}" for m in chat_history[-4:]]) if chat_history else "None"
        prompt = PLANNER_PROMPT.format(
            query=query,
            intent=intent.value,
            past_experience_hint=past_hint or "No prior experience recorded for this exact query pattern.",
            chat_history=formatted_history
        )

        # 4. Generate structured AgentPlan
        plan = llm_client.generate_structured(
            prompt=prompt,
            response_schema=AgentPlan,
            system_prompt="Formulate a structured execution plan for the AI Agent."
        )

        if not plan.query:
            plan.query = query

        # Enforce intent override and minimal context decision
        plan.intent = intent

        if intent in [IntentCategory.GENERAL_KNOWLEDGE, IntentCategory.NORMAL_CHAT]:
            plan.tools_to_use = []
            plan.requires_rag = False
            plan.requires_memory = False
            plan.context_decision = f"No external context or RAG required for {intent.value} request."

        elif intent == IntentCategory.CALCULATION:
            plan.requires_rag = False
            plan.requires_memory = False
            plan.context_decision = "Calculator tool execution required for mathematical computation. No RAG or memory."
            expr = re.sub(r"[^0-9\+\-\*\/\.\(\)\^%]", "", query).strip() or query
            plan.tools_to_use = [ToolCall(tool_name="calculator", arguments={"expression": expr})]

        elif intent == IntentCategory.MEMORY_QUERY:
            plan.requires_rag = False
            plan.requires_memory = True
            plan.context_decision = "Long-term memory search required for user facts. No RAG."
            plan.tools_to_use = [ToolCall(tool_name="memory_search", arguments={"query": query})]

        elif intent == IntentCategory.MEMORY_SAVE:
            plan.requires_rag = False
            plan.requires_memory = True
            plan.context_decision = "Long-term memory save required for user facts. No RAG."
            plan.tools_to_use = [ToolCall(tool_name="memory_save", arguments={"content": query, "category": "user_fact"})]

        elif intent in [IntentCategory.DOCUMENT_QUESTION, IntentCategory.DOCUMENT_SUMMARY]:
            plan.requires_rag = True
            plan.requires_memory = False
            plan.context_decision = f"Isolated document retrieval required on active conversation document for {intent.value}."
            plan.tools_to_use = [ToolCall(tool_name="knowledge_search", arguments={"query": query})]

        elif intent == IntentCategory.IMAGE_QUESTION:
            plan.tools_to_use = []
            plan.requires_rag = False
            plan.requires_memory = False
            plan.context_decision = "Attached image analysis required; no external document RAG."

        if past_hint:
            plan.past_experience_hint = past_hint
            if "CRITICAL USER LESSON" in past_hint and "Adapted strategy" not in plan.reasoning_summary:
                plan.reasoning_summary = f"Adapted strategy based on past user feedback lesson ({past_hint[:80]}...)"

        logger.info(f"Generated Plan: Intent={plan.intent}, Tools={[t.tool_name for t in plan.tools_to_use]}")
        return plan

    def _classify_intent(self, query: str, conversation_id: Optional[str] = None) -> IntentCategory:
        query_lower = query.strip().lower()

        # 1. Normal Chat:
        if query_lower in ["hello", "hi", "hey", "how are you", "good morning", "good evening", "greetings"]:
            return IntentCategory.NORMAL_CHAT

        # 2. Image Question:
        if any(kw in query_lower for kw in ["this image", "the image", "this screenshot", "attached image", "photo", "picture"]):
            return IntentCategory.IMAGE_QUESTION

        # 3. Calculation Check (math expressions like "2+2", "2 + 2", "25 * 16"):
        is_explicit_math = any(kw in query_lower for kw in ["calculate", "compute", "solve", "math", "sqrt(", "abs(", "pow("])
        is_pure_math_expr = bool(re.search(r"^\s*[\d\.\s\+\-\*\/\(\)\^%]+\s*$", query_lower))
        has_digit = bool(re.search(r"\d", query_lower))
        has_math_op = any(op in query_lower for op in ["+", "*", "/", "-"])

        if is_explicit_math or (is_pure_math_expr and has_digit and has_math_op) or (has_digit and has_math_op and len(query_lower.split()) <= 4 and not any(w in query_lower for w in ["resume", "doc", "page", "chapter", "version", "python", "java"])):
            return IntentCategory.CALCULATION

        # 4. Memory Save vs Memory Query:
        memory_query_kws = [
            "what is my", "what's my", "where do i", "where is my", "what did i say",
            "do you remember my", "recall my", "what are my", "tell me my", "do you know my",
            "what is my favorite", "recall my favorite", "my stored preference"
        ]
        is_query_question = any(kw in query_lower for kw in memory_query_kws) or query_lower.startswith("what is") or query_lower.startswith("where do")

        memory_save_kws = [
            "remember that", "remember my", "remember ", "store that", "store my", "save my",
            "please remember", "note that", "my favorite", "my name is", "i live in",
            "my job is", "my role is", "my preference is", "i prefer"
        ]
        is_fact_declaration = any(kw in query_lower for kw in memory_save_kws)

        if is_query_question and any(kw in query_lower for kw in ["favorite", "name", "live", "job", "role", "city", "preference", "programming", "language", "color", "food", "said"]):
            return IntentCategory.MEMORY_QUERY

        if is_fact_declaration and not (is_query_question and query_lower.endswith("?")):
            return IntentCategory.MEMORY_SAVE

        if is_query_question and any(kw in query_lower for kw in ["remember", "recall", "stored", "memory"]):
            return IntentCategory.MEMORY_QUERY

        # 5. Document Summary:
        if any(kw in query_lower for kw in ["summarize", "summary", "resume summary", "narrate my resume", "overview of document", "overview of pdf"]):
            return IntentCategory.DOCUMENT_SUMMARY

        # 6. Document Question (Explicit document/resume queries or active conversation document questions):
        doc_explicit_kws = [
            "resume", "cv", "policy", "cheatsheet", "kb", "my technical skills",
            "according to my resume", "in my resume", "my skills according to",
            "what does my resume say", "what does the pdf say", "in the document",
            "uploaded document", "attached document", "attached pdf", "from the pdf",
            "what is this document about", "what is this pdf about", "about this document", "about this pdf"
        ]
        if any(kw in query_lower for kw in doc_explicit_kws):
            return IntentCategory.DOCUMENT_QUESTION

        from app.rag import rag_engine
        if conversation_id and rag_engine.has_indexed_documents(conversation_id):
            if any(kw in query_lower for kw in ["skill", "skills", "experience", "education", "project", "projects", "work", "background", "qualification", "segment-iq", "vlsi"]):
                return IntentCategory.DOCUMENT_QUESTION

        # 7. Other Tool Requests (File/Web):
        if any(kw in query_lower for kw in ["read file", "open file", "inspect file"]):
            return IntentCategory.OTHER_TOOL_REQUEST
        if any(kw in query_lower for kw in ["weather", "news", "today", "latest web"]):
            return IntentCategory.OTHER_TOOL_REQUEST

        # 8. General Knowledge (default for general questions like "Define Python", "Explain recursion"):
        return IntentCategory.GENERAL_KNOWLEDGE

planner = AgentPlanner()

