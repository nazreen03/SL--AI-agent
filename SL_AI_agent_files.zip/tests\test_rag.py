import pytest
import tempfile
from pathlib import Path
import os
from app.rag import RAGEngine

@pytest.fixture
def temp_rag_engine():
    with tempfile.NamedTemporaryFile(suffix=".db", delete=False) as f:
        db_path = Path(f.name)
    rag = RAGEngine(db_path=db_path)
    yield rag
    try:
        if db_path.exists():
            os.remove(db_path)
    except Exception:
        pass


def test_chunking_mechanism(temp_rag_engine):
    sample_text = "Paragraph one goes here with some details. " * 20
    chunks = temp_rag_engine.chunk_text(sample_text, chunk_size=200, overlap=20)
    assert len(chunks) > 1
    assert all(len(c) <= 220 for c in chunks)

def test_ingest_and_search_txt(temp_rag_engine):
    with tempfile.NamedTemporaryFile(suffix=".txt", delete=False, mode="w", encoding="utf-8") as f:
        f.write("Self-Learning AI Agent concept guide by Dave Ebbelaar. Focuses on custom tool calling and RAG.")
        txt_path = Path(f.name)

    try:
        chunks_count, msg = temp_rag_engine.ingest_file(txt_path)
        assert chunks_count > 0
        
        results = temp_rag_engine.search_similar("Ebbelaar tool calling")
        assert len(results) >= 1
        assert "Dave Ebbelaar" in results[0][1]
    finally:
        if txt_path.exists():
            os.remove(txt_path)
