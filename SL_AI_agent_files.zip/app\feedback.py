from typing import Optional
from app.memory import memory_db
from app.logger import logger

class FeedbackHandler:
    """User feedback engine processing user ratings and feeding back into self-learning database."""

    def process_feedback(self, message_id: str, is_helpful: bool, comment: Optional[str] = None):
        logger.info(f"Processing user feedback for message '{message_id}': Helpful={is_helpful}, Comment={comment}")
        memory_db.record_user_feedback(
            message_id=message_id,
            is_helpful=is_helpful,
            comment=comment
        )
        return {"status": "success", "message_id": message_id, "is_helpful": is_helpful}

feedback_handler = FeedbackHandler()
