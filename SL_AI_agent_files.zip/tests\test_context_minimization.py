import pytest
from app.schemas import ChatRequest, IntentCategory
from app.agent import agent
from app.planner import planner
from app.memory import memory_db

@pytest.mark.asyncio
async def test_pure_math_expression_2_plus_2():
    """Test 1: '2+2' -> CALCULATION, calculator only, exact answer '4'."""
    req = ChatRequest(query="2+2")
    resp = await agent.run(req)

    plan = planner.plan(req.query, [])
    assert plan.intent == IntentCategory.CALCULATION
    assert any(t.tool_name == "calculator" for t in plan.tools_to_use)
    assert plan.requires_rag is False

    assert "calculator" in resp.tools_used
    assert len(resp.rag_context) == 0
    assert resp.answer == "4"
    assert resp.evaluation.total_score >= 70

@pytest.mark.asyncio
async def test_math_expression_25_times_16():
    """Test 1b: '25 * 16' -> CALCULATION, calculator only, exact answer '400'."""
    req = ChatRequest(query="25 * 16")
    resp = await agent.run(req)

    plan = planner.plan(req.query, [])
    assert plan.intent == IntentCategory.CALCULATION
    assert any(t.tool_name == "calculator" for t in plan.tools_to_use)
    assert plan.requires_rag is False

    assert "calculator" in resp.tools_used
    assert len(resp.rag_context) == 0
    assert resp.answer == "400"
    assert resp.evaluation.total_score >= 70

@pytest.mark.asyncio
async def test_general_knowledge_intent_define_python():
    """Test 2: 'Define Python.' -> GENERAL_KNOWLEDGE, NO RAG, NO calculator, NO memory."""
    req = ChatRequest(query="Define Python.")
    resp = await agent.run(req)

    plan = planner.plan(req.query, [])
    assert plan.intent == IntentCategory.GENERAL_KNOWLEDGE
    assert len(plan.tools_to_use) == 0
    assert plan.requires_rag is False
    assert plan.requires_memory is False

    assert "calculator" not in resp.tools_used
    assert len(resp.rag_context) == 0
    assert resp.evaluation.total_score >= 70

@pytest.mark.asyncio
async def test_normal_chat_hello():
    """Test 3: 'Hello' -> NORMAL_CHAT, minimal context, NO RAG."""
    req = ChatRequest(query="Hello")
    resp = await agent.run(req)

    plan = planner.plan(req.query, [])
    assert plan.intent == IntentCategory.NORMAL_CHAT
    assert len(plan.tools_to_use) == 0
    assert plan.requires_rag is False
    assert len(resp.rag_context) == 0

@pytest.mark.asyncio
async def test_save_favorite_language_intent():
    """Test 4: 'Remember that my favorite language is Python.' -> MEMORY_SAVE."""
    query = "Remember that my favorite language is Python."
    plan = planner.plan(query, [])

    assert plan.intent == IntentCategory.MEMORY_SAVE
    assert any(t.tool_name == "memory_save" for t in plan.tools_to_use)
    assert plan.requires_rag is False
    assert plan.requires_memory is True

@pytest.mark.asyncio
async def test_query_favorite_language_intent():
    """Test 5: 'What is my favorite language?' -> MEMORY_QUERY."""
    query = "What is my favorite language?"
    plan = planner.plan(query, [])

    assert plan.intent in [IntentCategory.MEMORY_QUERY, IntentCategory.PREVIOUS_MEMORY]
    assert any(t.tool_name == "memory_search" for t in plan.tools_to_use)
    assert plan.requires_rag is False
    assert plan.requires_memory is True

@pytest.mark.asyncio
async def test_resume_question_intent():
    """Test 6: 'What are my technical skills according to my resume?' -> DOCUMENT_QUESTION."""
    query = "What are my technical skills according to my resume?"
    plan = planner.plan(query, [])

    assert plan.intent in [IntentCategory.DOCUMENT_QUESTION, IntentCategory.DOCUMENT_RAG]
    assert any(t.tool_name == "knowledge_search" for t in plan.tools_to_use)
    assert plan.requires_rag is True

@pytest.mark.asyncio
async def test_resume_summary_intent():
    """Test 7: 'Summarize my resume.' -> DOCUMENT_SUMMARY."""
    query = "Summarize my resume."
    plan = planner.plan(query, [])

    assert plan.intent == IntentCategory.DOCUMENT_SUMMARY
    assert any(t.tool_name == "knowledge_search" for t in plan.tools_to_use)
    assert plan.requires_rag is True

@pytest.mark.asyncio
async def test_image_question_intent():
    """Test 8: 'What does this image show?' -> IMAGE_QUESTION."""
    query = "What does this image show?"
    plan = planner.plan(query, [])

    assert plan.intent == IntentCategory.IMAGE_QUESTION
    assert len(plan.tools_to_use) == 0
    assert plan.requires_rag is False

def test_memory_deduplication_bug_2():
    """Test 9: Repeated identical memory fact updates/deduplicates without creating duplicate rows."""
    content1 = "Remember that my favorite language is Python."
    id1 = memory_db.save_memory(content1)
    assert id1 > 0

    # Save exact same fact again -> Should return same ID without inserting duplicate row
    id2 = memory_db.save_memory(content1)
    assert id1 == id2

    # Save updated fact -> Should upsert topic (favorite language)
    content2 = "My favorite language is Java now."
    id3 = memory_db.save_memory(content2)
    assert id1 == id3

    # Check database row content
    memories = memory_db.list_all_memories()
    java_memories = [m for m in memories if "Java" in m.content]
    assert len(java_memories) >= 1

def test_system_prompt_guard_bug_3():
    """Test 10: System/planner prompts MUST NOT be saved into user memory."""
    sys_prompt = "You are a Self-Learning AI Agent Planner. Available Tools: calculator..."
    res_id = memory_db.save_memory(sys_prompt)
    assert res_id == -1

    all_memories = memory_db.list_all_memories()
    assert not any(sys_prompt in m.content for m in all_memories)
