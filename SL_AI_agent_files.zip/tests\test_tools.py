import pytest
from app.tools import tool_calculator, tool_registry, tool_file_reader

def test_calculator_basic_operations():
    res = tool_calculator("15 * 4 + 10")
    assert res.success is True
    assert res.output == "70"

def test_calculator_advanced_functions():
    res = tool_calculator("sqrt(16) + abs(-5)")
    assert res.success is True
    assert float(res.output) == 9.0

def test_calculator_invalid_expression():
    res = tool_calculator("invalid_func()")
    assert res.success is False
    assert "Unsupported function" in res.error or "Invalid math" in res.error

def test_tool_registry_execution():
    res = tool_registry.execute("calculator", {"expression": "100 / 4"})
    assert res.success is True
    assert res.output == "25.0"

def test_tool_file_reader_nonexistent():
    res = tool_file_reader("nonexistent_file_xyz.txt")
    assert res.success is False
    assert "not found" in res.error.lower()
