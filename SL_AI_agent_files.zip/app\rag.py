import sqlite3
import json
import uuid
import numpy as np
from pathlib import Path
from typing import List, Dict, Any, Tuple, Optional
from app.config import settings
from app.logger import logger
from app.schemas import ToolResult

class RAGEngine:
    """Document Ingestion, Text Chunker, Vector Embedding Engine, and Similarity Searcher using SQLite."""

    def __init__(self, db_path: Path = settings.DB_PATH):
        self.db_path = db_path
        self._init_rag_db()

    def _get_connection(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        return conn

    def _init_rag_db(self):
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
            CREATE TABLE IF NOT EXISTS rag_chunks (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                filename TEXT NOT NULL,
                chunk_index INTEGER NOT NULL,
                content TEXT NOT NULL,
                vector_json TEXT NOT NULL,
                conversation_id TEXT,
                document_id TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
            """)
            try:
                cursor.execute("ALTER TABLE rag_chunks ADD COLUMN conversation_id TEXT")
            except Exception:
                pass
            try:
                cursor.execute("ALTER TABLE rag_chunks ADD COLUMN document_id TEXT")
            except Exception:
                pass
            conn.commit()
            logger.info("Initialized RAG vector storage table.")

    def chunk_text(self, text: str, chunk_size: int = 500, overlap: int = 50) -> List[str]:
        """Split text recursively by paragraphs, sentences, or characters into overlapping chunks."""
        text = text.strip()
        if not text:
            return []

        chunks = []
        start = 0
        text_len = len(text)

        while start < text_len:
            end = min(start + chunk_size, text_len)
            
            # Try finding natural boundary
            if end < text_len:
                last_space = text.rfind(" ", start, end)
                if last_space > start + (chunk_size // 2):
                    end = last_space

            chunk = text[start:end].strip()
            if chunk:
                chunks.append(chunk)

            start = max(end - overlap, start + 1)
            if end >= text_len:
                break

        return chunks

    def compute_embedding(self, text: str) -> np.ndarray:
        """Compute vector embedding using OpenAI API or lightweight TF-IDF character n-gram fallback."""
        if settings.is_api_key_configured and settings.LLM_PROVIDER != "mock":
            try:
                from openai import OpenAI
                client = OpenAI(api_key=settings.OPENAI_API_KEY, base_url=settings.OPENAI_BASE_URL)
                response = client.embeddings.create(
                    input=text,
                    model=settings.EMBEDDING_MODEL
                )
                vec = response.data[0].embedding
                return np.array(vec, dtype=np.float32)
            except Exception as e:
                logger.warning(f"OpenAI embedding call failed ({e}). Falling back to local vectorizer.")

        # Local deterministic hashing TF-IDF vectorizer fallback (128-dim)
        dim = 128
        vec = np.zeros(dim, dtype=np.float32)
        words = text.lower().split()
        for w in words:
            idx = hash(w) % dim
            vec[idx] += 1.0
        
        norm = np.linalg.norm(vec)
        if norm > 0:
            vec /= norm
        return vec

    def has_indexed_documents(self, conversation_id: Optional[str] = None) -> bool:
        """Check if vector database contains any indexed text chunks."""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            if conversation_id:
                cursor.execute("SELECT COUNT(*) FROM rag_chunks WHERE conversation_id = ? OR conversation_id IS NULL", (conversation_id,))
            else:
                cursor.execute("SELECT COUNT(*) FROM rag_chunks")
            row = cursor.fetchone()
            return row[0] > 0 if row else False

    def ingest_file(self, filepath: Path, conversation_id: Optional[str] = None) -> Tuple[int, str]:
        """Process PDF, TXT, or Markdown document, chunk, embed, and index into DB bound to conversation."""
        filename = filepath.name
        suffix = filepath.suffix.lower()
        text = ""
        page_count = 1
        document_id = str(uuid.uuid4())
        stored_path = str(filepath.resolve())

        from app.memory import memory_db
        conv_id = memory_db.ensure_conversation(conversation_id)

        try:
            if suffix == ".pdf":
                from pypdf import PdfReader
                reader = PdfReader(str(filepath))
                page_count = len(reader.pages)
                text = "\n".join([p.extract_text() or "" for p in reader.pages])
            elif suffix in [".txt", ".md", ".markdown"]:
                text = filepath.read_text(encoding="utf-8", errors="replace")
            else:
                return 0, f"Unsupported file type '{suffix}'. Use .pdf, .txt, or .md."

            chunks = self.chunk_text(text)
            if not chunks:
                return 0, "File contained no extractable text."

            # Save Document Metadata to DB
            memory_db.save_document(document_id, filename, stored_path, conv_id)

            logger.info(
                f"\nUPLOAD:\n"
                f"filename = {filename}\n"
                f"document_id = {document_id}\n"
                f"conversation_id = {conv_id}\n"
                f"session_id = {conv_id}\n"
                f"stored_path = {stored_path}"
            )

            with self._get_connection() as conn:
                cursor = conn.cursor()
                # Remove previous chunks for same filename in conversation to allow re-indexing
                cursor.execute("DELETE FROM rag_chunks WHERE filename = ? AND conversation_id = ?", (filename, conv_id))

                for i, chunk in enumerate(chunks):
                    vec = self.compute_embedding(chunk)
                    vec_json = json.dumps(vec.tolist())
                    cursor.execute(
                        "INSERT INTO rag_chunks (filename, chunk_index, content, vector_json, conversation_id, document_id) VALUES (?, ?, ?, ?, ?, ?)",
                        (filename, i, chunk, vec_json, conv_id, document_id)
                    )
                conn.commit()

            memory_db.set_active_document(conv_id, document_id, filename)

            logger.info(f"Chunks indexed = {len(chunks)}. Document '{filename}' (id={document_id}) bound to conversation: {conv_id}")
            return len(chunks), f"Successfully ingested {filename} ({page_count} pages, {len(chunks)} chunks indexed)."

        except Exception as e:
            logger.error(f"Failed to ingest file '{filename}': {e}")
            return 0, f"Ingestion error: {str(e)}"

    def search_similar(
        self,
        query: str,
        top_k: int = 3,
        conversation_id: Optional[str] = None,
        is_summarization: bool = False
    ) -> List[Tuple[str, str, float]]:
        """Retrieve relevant chunks with strict active document isolation."""
        from app.memory import memory_db
        active_doc_id = memory_db.get_active_document_id(conversation_id) if conversation_id else None
        active_filename = memory_db.get_active_document(conversation_id) if conversation_id else None
        
        with self._get_connection() as conn:
            cursor = conn.cursor()
            
            # Active Document Isolation: Filter strictly by active document or conversation ID
            if active_doc_id or active_filename:
                cursor.execute(
                    "SELECT filename, chunk_index, content, vector_json FROM rag_chunks WHERE (document_id = ? OR filename = ?) ORDER BY chunk_index ASC",
                    (active_doc_id, active_filename)
                )
            elif conversation_id:
                cursor.execute(
                    "SELECT filename, chunk_index, content, vector_json FROM rag_chunks WHERE conversation_id = ? ORDER BY chunk_index ASC",
                    (conversation_id,)
                )
            else:
                cursor.execute("SELECT filename, chunk_index, content, vector_json FROM rag_chunks ORDER BY id DESC")

            rows = cursor.fetchall()

        if not rows:
            return []

        # Comprehensive Summarization: Retrieve all chunks of active document in sequential order
        if is_summarization:
            return [(r["filename"], r["content"], 1.0) for r in rows]

        # Vector Similarity Search for specific question
        query_vec = self.compute_embedding(query)
        results = []
        for r in rows:
            try:
                vec = np.array(json.loads(r["vector_json"]), dtype=np.float32)
                norm_q = np.linalg.norm(query_vec)
                norm_v = np.linalg.norm(vec)
                similarity = 0.0
                if norm_q > 0 and norm_v > 0:
                    similarity = float(np.dot(query_vec, vec) / (norm_q * norm_v))

                results.append((r["filename"], r["content"], similarity))
            except Exception:
                continue

        results.sort(key=lambda x: x[2], reverse=True)
        return results[:top_k]

    def search_tool(
        self,
        query: str,
        top_k: int = 3,
        conversation_id: Optional[str] = None,
        is_summarization: bool = False
    ) -> ToolResult:
        try:
            results = self.search_similar(query, top_k=top_k, conversation_id=conversation_id, is_summarization=is_summarization)
            if not results:
                return ToolResult(
                    tool_name="knowledge_search",
                    success=True,
                    output="No active document found for this conversation."
                )

            target_doc = results[0][0]
            if is_summarization:
                formatted = "\n\n".join([content for fn, content, _ in results])
                return ToolResult(
                    tool_name="knowledge_search",
                    success=True,
                    output=f"Full Document Content for Summarization [{target_doc}] ({len(results)} chunks):\n{formatted}"
                )

            formatted = "\n---\n".join([content for fn, content, score in results])
            return ToolResult(
                tool_name="knowledge_search",
                success=True,
                output=f"Retrieved Document Content [{target_doc}]:\n{formatted}"
            )
        except Exception as e:
            return ToolResult(tool_name="knowledge_search", success=False, output="", error=str(e))

rag_engine = RAGEngine()
