import pytest
import asyncio
from app.schemas import ChatRequest
from app.agent import agent
from app.memory import memory_db

def test_e2e_phase4_full_workflow():
    """
    End-to-End Validation of Phase 4 Feedback-Based Self-Improvement Loop:
    1. Session 1: User asks "Explain recursion to a beginner." -> Agent generates response.
    2. User submits 👎 feedback with comment: "Too complicated. Explain it using a very simple real-world example."
    3. Verify feedback comment is recorded in learning_experiences table in SQLite DB.
    4. Session 2 (NEW conversation): User asks "Explain binary search to me."
    5. Verify Agent trace contains 'Retrieved relevant learning experience' and 'Adapted strategy'.
    6. Verify generated answer reflects the learned strategy adaptation (uses real-world analogy like dictionary/phonebook lookup).
    7. User submits 👍 feedback -> Verify positive feedback is recorded without duplicate rows.
    """
    # Clear DB tables for fresh E2E execution
    with memory_db._get_connection() as conn:
        conn.cursor().execute("DELETE FROM learning_experiences")
        conn.cursor().execute("DELETE FROM user_feedback")
        conn.commit()

    # Step 1: Session 1 - Initial task
    conv1_id = "conv-session-phase4-1"
    req1 = ChatRequest(
        query="Explain recursion to a beginner.",
        conversation_id=conv1_id
    )
    res1 = asyncio.run(agent.run(req1))
    assert res1.answer is not None

    # Step 2: Submit 👎 negative feedback with explicit guidance comment
    memory_db.record_user_feedback(
        message_id=res1.message_id,
        is_helpful=False,
        comment="Too complicated. Explain it using a very simple real-world example."
    )

    # Step 3: Verify learning experience updated in DB
    exps = memory_db.get_relevant_learning_experiences("recursion", "GENERAL_KNOWLEDGE")
    assert len(exps) == 1
    assert exps[0].user_feedback is False
    assert exps[0].feedback_comment == "Too complicated. Explain it using a very simple real-world example."

    # Step 4: Session 2 (NEW conversation) - Similar task
    conv2_id = "conv-session-phase4-2"
    req2 = ChatRequest(
        query="Explain binary search to me.",
        conversation_id=conv2_id
    )
    res2 = asyncio.run(agent.run(req2))

    # Step 5: Verify Activity Trace shows experience retrieval & strategy adaptation
    step_names = [s.step_name for s in res2.steps]
    assert "Retrieved relevant learning experience" in step_names, f"Expected experience retrieval step, found: {step_names}"
    assert "Adapted strategy" in step_names, f"Expected strategy adaptation step, found: {step_names}"

    # Step 6: Verify Response reflects learned improvement (uses real-world analogy)
    answer_lower = res2.answer.lower()
    has_analogy = any(kw in answer_lower for kw in ["dictionary", "phonebook", "middle", "analog", "doll", "page"])
    assert has_analogy, f"Expected real-world analogy in adapted answer, got: '{res2.answer}'"

    # Step 7: Submit 👍 positive feedback for adapted response
    memory_db.record_user_feedback(
        message_id=res2.message_id,
        is_helpful=True,
        comment="Great real-world analogy, very clear!"
    )

    # Step 8: Verify no duplicate learning experience records created
    all_exps = memory_db.get_relevant_learning_experiences("binary search", "GENERAL_KNOWLEDGE")
    assert len(all_exps) <= 2, f"Expected at most 2 distinct topic experiences, found {len(all_exps)}"

    print("E2E Phase 4 Feedback-Based Self-Improvement Loop PASSED cleanly!")

if __name__ == "__main__":
    test_e2e_phase4_full_workflow()
