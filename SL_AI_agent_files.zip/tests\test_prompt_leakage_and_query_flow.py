import pytest
from app.agent import agent
from app.schemas import ChatRequest, ChatResponse, IntentCategory
from app.planner import planner

@pytest.mark.asyncio
async def test_narrate_about_it_query_flow_and_no_prompt_leak():
    """Verify that 'narrate about it' query pipeline preserves exact query, does not leak internal prompts,
    does not truncate query, and returns a natural language response."""
    user_query = "narrate about it"
    req = ChatRequest(query=user_query)
    resp = await agent.run(req)

    # 1. Exact user query preserved
    assert resp.query == user_query

    # 2. Final answer is natural language, NOT internal prompt, debug message, or truncated string
    assert "You are a Self-Learning AI Agent synthesizing" not in resp.answer
    assert "Processed query response for:" not in resp.answer
    assert "narrate abou." not in resp.answer
    assert len(resp.answer) > 10
    assert "narrate" in resp.answer.lower() or "explain" in resp.answer.lower()

    # 3. Activity trace does not expose internal prompts
    for step in resp.steps:
        assert "You are a Self-Learning AI Agent synthesizing" not in step.description
        assert "Processed query response for:" not in step.description

    # 4. Evaluation score passes
    assert resp.score >= 70

@pytest.mark.asyncio
async def test_general_query_preserves_query_and_no_leak():
    """Verify arbitrary general knowledge queries preserve exact query without prompt leakage or truncation."""
    user_query = "Explain how quantum computing differs from classical computing"
    req = ChatRequest(query=user_query)
    resp = await agent.run(req)

    assert resp.query == user_query
    assert "You are a Self-Learning AI Agent synthesizing" not in resp.answer
    assert "Processed query response for:" not in resp.answer
    assert resp.query not in resp.answer or user_query in resp.answer
    assert len(resp.answer) > 10
