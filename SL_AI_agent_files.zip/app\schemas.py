from enum import Enum
from typing import List, Dict, Any, Optional
from pydantic import BaseModel, Field, ConfigDict

class IntentCategory(str, Enum):
    GENERAL_KNOWLEDGE = "GENERAL_KNOWLEDGE"
    NORMAL_CHAT = "NORMAL_CHAT"
    CALCULATION = "CALCULATION"
    MEMORY_QUERY = "MEMORY_QUERY"
    MEMORY_SAVE = "MEMORY_SAVE"
    DOCUMENT_QUESTION = "DOCUMENT_QUESTION"
    DOCUMENT_SUMMARY = "DOCUMENT_SUMMARY"
    IMAGE_QUESTION = "IMAGE_QUESTION"
    OTHER_TOOL_REQUEST = "OTHER_TOOL_REQUEST"
    PREVIOUS_MEMORY = "MEMORY_QUERY"
    DOCUMENT_RAG = "DOCUMENT_QUESTION"
    GENERAL_QUESTION = "GENERAL_KNOWLEDGE"

class ToolCall(BaseModel):
    tool_name: str = Field(description="Name of the tool to execute")
    arguments: Dict[str, Any] = Field(default_factory=dict, description="Key-value arguments for tool function")

class ToolResult(BaseModel):
    tool_name: str
    success: bool
    output: str
    error: Optional[str] = None

class AgentStep(BaseModel):
    step_name: str = Field(description="Display step name e.g. Understanding request, Planning, Using tool")
    description: str = Field(description="Simplified non-private description of action taken")
    tool_name: Optional[str] = None
    status: str = Field(default="completed", description="status: pending, in_progress, completed, failed")
    details: Optional[Dict[str, Any]] = None

class AgentPlan(BaseModel):
    query: str
    intent: IntentCategory
    reasoning_summary: str = Field(description="High-level plan summary without private CoT")
    context_decision: Optional[str] = Field(default="No external context required", description="Explanation of why context was included or omitted")
    tools_to_use: List[ToolCall] = Field(default_factory=list, description="Ordered list of tool calls")
    requires_rag: bool = False
    requires_memory: bool = False
    past_experience_hint: Optional[str] = None

class EvaluationResult(BaseModel):
    relevance_score: int = Field(ge=0, le=10, description="Relevance score out of 10")
    correctness_score: int = Field(ge=0, le=10, description="Correctness score out of 10")
    completeness_score: int = Field(ge=0, le=10, description="Completeness score out of 10")
    total_score: int = Field(ge=0, le=100, description="Overall evaluation score out of 100")
    status: str = Field(description="PASS or RETRY")
    improvement_feedback: str = Field(description="Short actionable feedback for retry if needed")
    task_completed: bool = Field(default=True)
    context_used_properly: bool = Field(default=True)

class ChatRequest(BaseModel):
    query: str = Field(..., min_length=1, description="User question or prompt")
    conversation_id: Optional[str] = Field(default=None, description="Existing conversation ID or null for new")

class ChatResponse(BaseModel):
    message_id: str
    conversation_id: str
    query: str
    answer: str
    evaluation: EvaluationResult
    attempts: int
    steps: List[AgentStep]
    tools_used: List[str]
    rag_context: List[str]
    score: int

class FeedbackRequest(BaseModel):
    message_id: str
    is_helpful: bool
    comment: Optional[str] = None

class DocumentUploadResponse(BaseModel):
    filename: str
    chunks_created: int
    status: str

class MemoryItem(BaseModel):
    id: int
    content: str
    category: str
    created_at: str

class LearningExperience(BaseModel):
    id: int
    task_type: str
    user_query: str
    approach_summary: str
    tools_used: List[str]
    score: int
    user_feedback: Optional[bool]
    feedback_comment: Optional[str] = None
    success: bool
    created_at: str
