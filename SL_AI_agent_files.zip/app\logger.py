import logging
import sys
import re
from app.config import settings

class SecretMaskingFormatter(logging.Formatter):
    """Custom logging formatter that strips sensitive credentials from log messages."""
    
    SECRET_PATTERNS = [
        r"sk-[a-zA-Z0-9T3BlbkFJ]{20,}",
        r"api[_-]?key=['\"]?([a-zA-Z0-9_\-]+)['\"]?",
        r"bearer\s+([a-zA-Z0-9_\-\.]+)"
    ]

    def format(self, record: logging.LogRecord) -> str:
        formatted = super().format(record)
        for pattern in self.SECRET_PATTERNS:
            formatted = re.sub(pattern, "[REDACTED_SECRET]", formatted, flags=re.IGNORECASE)
        return formatted

def setup_logger(name: str = "agent_logger") -> logging.Logger:
    logger = logging.getLogger(name)
    logger.setLevel(logging.INFO)
    
    if logger.handlers:
        return logger

    # Log format
    fmt = "%(asctime)s - [%(levelname)s] - %(name)s - %(message)s"
    formatter = SecretMaskingFormatter(fmt)

    # Console Handler
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setFormatter(formatter)
    logger.addHandler(console_handler)

    # File Handler
    file_handler = logging.FileHandler(settings.LOG_PATH, encoding="utf-8")
    file_handler.setFormatter(formatter)
    logger.addHandler(file_handler)

    return logger

logger = setup_logger()
