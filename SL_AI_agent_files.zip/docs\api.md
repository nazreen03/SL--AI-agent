# Self-Learning AI Agent — REST API Documentation

This document describes the FastAPI REST API endpoints available for interaction with the **Self-Learning AI Agent**.

---

## 📌 Base URL
```http
http://127.0.0.1:8000
```
Interactive OpenAPI Swagger documentation is available at:
```http
http://127.0.0.1:8000/docs
```

---

## 🚀 Endpoints Reference

### 1. `POST /chat`
Execute a query through the full agent loop (Understand → Plan → Retrieve/Tools → Synthesize → Self-Evaluate → Record Experience).

- **Request Body** (`ChatRequest`):
```json
{
  "query": "Calculate 125 * 24 and explain the result simply.",
  "conversation_id": "conv-12345"
}
```

- **Response Body** (`ChatResponse`):
```json
{
  "message_id": "8f112671-ea54-4d7f-9136-eb7aa522e3e0",
  "conversation_id": "conv-12345",
  "query": "Calculate 125 * 24 and explain the result simply.",
  "answer": "3000",
  "evaluation": {
    "relevance_score": 10,
    "correctness_score": 10,
    "completeness_score": 10,
    "total_score": 100,
    "status": "PASS",
    "improvement_feedback": "Answer directly addresses calculation.",
    "task_completed": true,
    "context_used_properly": true
  },
  "attempts": 1,
  "steps": [
    {
      "step_name": "Understanding request",
      "description": "Intent: CALCULATION",
      "status": "completed"
    },
    {
      "step_name": "Planning",
      "description": "Formulated plan for CALCULATION request.",
      "status": "completed"
    },
    {
      "step_name": "Selecting tools",
      "description": "Selected 1 tool(s): ['calculator'].",
      "status": "completed"
    },
    {
      "step_name": "Executing tool",
      "tool_name": "calculator",
      "description": "Successfully executed tool 'calculator'.",
      "status": "completed"
    },
    {
      "step_name": "Generating answer",
      "description": "Generating answer for CALCULATION",
      "status": "completed"
    },
    {
      "step_name": "Evaluating response",
      "description": "Running self-evaluation monitor on answer quality.",
      "status": "completed"
    },
    {
      "step_name": "Completed",
      "description": "Task finished in 1 attempt(s) with final evaluation score 100/100.",
      "status": "completed"
    }
  ],
  "tools_used": ["calculator"],
  "rag_context": [],
  "score": 100
}
```

---

### 2. `POST /feedback`
Record user thumbs up/down rating and custom guidance comment to trigger strategy adaptation in future sessions.

- **Request Body** (`FeedbackRequest`):
```json
{
  "message_id": "8f112671-ea54-4d7f-9136-eb7aa522e3e0",
  "is_helpful": false,
  "comment": "Too complicated. Use a very simple real-world analogy and explain it step by step."
}
```

- **Response Body**:
```json
{
  "status": "success",
  "message_id": "8f112671-ea54-4d7f-9136-eb7aa522e3e0",
  "is_helpful": false
}
```

---

### 3. `POST /documents`
Upload and index a PDF, TXT, or Markdown document into the RAG vector storage bound to the specified conversation ID.

- **Content-Type**: `multipart/form-data`
- **Query Parameter**: `conversation_id` (optional `string`)
- **Form File**: `file` (`.pdf`, `.txt`, `.md`)

- **Response Body** (`DocumentUploadResponse`):
```json
{
  "filename": "sample_kb.pdf",
  "chunks_created": 4,
  "status": "Successfully ingested sample_kb.pdf (2 pages, 4 chunks indexed)."
}
```

---

### 4. `GET /memory`
Retrieve stored long-term user facts, preferences, and self-learning experience logs.

- **Query Parameter**: `query` (optional `string`)

- **Response Body**:
```json
{
  "memories": [
    {
      "id": 1,
      "content": "My favorite programming language is Python",
      "category": "user_fact",
      "created_at": "2026-09-18 00:10:00"
    }
  ],
  "learning_experiences": [
    {
      "id": 1,
      "task_type": "GENERAL_KNOWLEDGE",
      "user_query": "Explain recursion to a beginner.",
      "approach_summary": "Categorized request as GENERAL_KNOWLEDGE",
      "tools_used": [],
      "score": 90,
      "user_feedback": false,
      "feedback_comment": "Too complicated. Use a very simple real-world analogy...",
      "success": true,
      "created_at": "2026-09-18 00:11:00"
    }
  ]
}
```

---

### 5. `GET /health`
System health check endpoint.

- **Response Body**:
```json
{
  "status": "healthy",
  "project": "Self-Learning AI Agent",
  "version": "1.0.0",
  "llm_provider": "openai",
  "is_api_key_set": true
}
```

---

### 6. `GET /logs`
Tail recent lines from application log file.

- **Query Parameter**: `lines` (default `50`, range `1-500`)

- **Response Body**:
```json
{
  "logs": [
    "2026-09-18 00:15:00 - [INFO] - agent_logger - Agent Loop Started: conv_id=conv-12345, query='...'",
    "2026-09-18 00:15:01 - [INFO] - agent_logger - Self-Evaluation Result: Score=100/100, Status=PASS"
  ]
}
```
