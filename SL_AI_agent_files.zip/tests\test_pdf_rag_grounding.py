import pytest
import asyncio
from pathlib import Path

from app.schemas import ChatRequest, IntentCategory
from app.agent import agent
from app.rag import rag_engine
from app.memory import memory_db

@pytest.fixture(autouse=True)
def setup_nazreen_resume(tmp_path):
    """Setup indexed Nazreen resume document before tests."""
    resume_path = tmp_path / "Nazreen_resume.txt"
    resume_content = """
    Nazreen Sultana
    Email: nazreen@example.com | Phone: (555) 789-0123

    SUMMARY
    Senior AI Software Engineer specializing in Agentic Workflows, Retrieval-Augmented Generation (RAG), and scalable FastAPI microservices.

    TECHNICAL SKILLS
    - Programming Languages: Python, C++, SQL, JavaScript
    - AI & Frameworks: PyTorch, LangChain, LlamaIndex, OpenAI API, Streamlit, NumPy
    - Databases & Tools: SQLite, Qdrant, Docker, Git, CI/CD

    WORK EXPERIENCE & PROJECTS
    1. Segment-IQ Analytics Engine: Developed customer segmentation AI module analyzing 1M user events per day using Python, PyTorch, and FastAPI. Improved classification accuracy by 35%.
    2. Self-Learning AI Agent Platform: Built autonomous agent framework with AST safe calculator, memory persistence, RAG vector indexing, and objective self-evaluation.

    EDUCATION
    B.Tech in Computer Science, 2023
    """
    resume_path.write_text(resume_content, encoding="utf-8")
    chunks, msg = rag_engine.ingest_file(resume_path, conversation_id="test_conv_nazreen")
    assert chunks > 0

@pytest.mark.asyncio
async def test_nazreen_resume_flow():
    conv_id = "test_conv_nazreen"

    # 1. "Summarize my resume"
    req1 = ChatRequest(query="Summarize my resume", conversation_id=conv_id)
    res1 = await agent.run(req1)
    assert res1.evaluation.status == "PASS"
    assert "Nazreen" in res1.answer or "Segment-IQ" in res1.answer or "uploaded document context" in res1.answer.lower()
    assert "calculator" not in res1.tools_used
    assert "knowledge_search" in res1.tools_used

    # 2. "What are my technical skills?"
    req2 = ChatRequest(query="What are my technical skills?", conversation_id=conv_id)
    res2 = await agent.run(req2)
    assert res2.evaluation.status == "PASS"
    assert "Python" in res2.answer or "PyTorch" in res2.answer or "uploaded document context" in res2.answer.lower()
    assert "calculator" not in res2.tools_used

    # 3. "What projects did I work on?"
    req3 = ChatRequest(query="What projects did I work on?", conversation_id=conv_id)
    res3 = await agent.run(req3)
    assert res3.evaluation.status == "PASS"
    assert "Segment-IQ" in res3.answer or "Agent Platform" in res3.answer or "uploaded document context" in res3.answer.lower()

    # 4. "Tell me more about Segment-IQ."
    req4 = ChatRequest(query="Tell me more about Segment-IQ.", conversation_id=conv_id)
    res4 = await agent.run(req4)
    assert res4.evaluation.status == "PASS"
    assert "Segment-IQ" in res4.answer or "customer segmentation" in res4.answer or "uploaded document context" in res4.answer.lower()

    # 5. Calculation query: "Calculate 25 * 16"
    req5 = ChatRequest(query="Calculate 25 * 16.", conversation_id=conv_id)
    res5 = await agent.run(req5)
    assert "calculator" in res5.tools_used
    assert "400" in res5.answer
