import pytest
from app.evaluator import AgentEvaluator
from app.schemas import EvaluationResult

def test_evaluator_pass():
    ev_engine = AgentEvaluator()
    res = ev_engine.evaluate(
        query="What is 10 + 20?",
        answer="The answer to 10 + 20 is 30.",
        context="Tool 'calculator' output: 30"
    )
    assert isinstance(res, EvaluationResult)
    assert res.total_score >= 70
    assert res.status == "PASS"

def test_evaluator_schema_fields():
    ev_engine = AgentEvaluator()
    res = ev_engine.evaluate(
        query="Explain RAG",
        answer="RAG stands for Retrieval-Augmented Generation.",
        context="Doc RAG details"
    )
    assert 0 <= res.relevance_score <= 10
    assert 0 <= res.correctness_score <= 10
    assert 0 <= res.completeness_score <= 10
    assert 0 <= res.total_score <= 100
