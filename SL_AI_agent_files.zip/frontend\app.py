import streamlit as st
import asyncio
import os
import sys
from pathlib import Path

# Add parent dir to path so imports work smoothly
BASE_DIR = Path(__file__).resolve().parent.parent
SCRIPT_DIR = Path(__file__).resolve().parent
if str(SCRIPT_DIR) in sys.path:
    sys.path.remove(str(SCRIPT_DIR))
if str(BASE_DIR) not in sys.path:
    sys.path.insert(0, str(BASE_DIR))

from app.schemas import ChatRequest, FeedbackRequest
from app.agent import agent
from app.feedback import feedback_handler
from app.rag import rag_engine
from app.memory import memory_db
from app.config import settings

st.set_page_config(
    page_title="Self-Learning AI Agent",
    page_icon="🧠",
    layout="wide",
    initial_sidebar_state="expanded"
)

# --- Custom Styling ---
st.markdown("""
<style>
    /* Main Theme */
    .stApp {
        background-color: #0d1117;
        color: #c9d1d9;
    }
    
    /* Card Container */
    .metric-card {
        background: rgba(22, 27, 34, 0.8);
        border: 1px solid rgba(48, 54, 61, 0.7);
        border-radius: 12px;
        padding: 16px;
        margin-bottom: 12px;
        backdrop-filter: blur(10px);
    }
    
    /* Activity Step Trace */
    .step-badge {
        display: inline-block;
        background-color: #1f2937;
        border: 1px solid #374151;
        color: #9ca3af;
        border-radius: 20px;
        padding: 4px 12px;
        font-size: 0.82rem;
        margin-right: 6px;
        margin-bottom: 6px;
    }
    
    .step-active {
        background-color: #1e3a8a;
        border-color: #3b82f6;
        color: #93c5fd;
        font-weight: bold;
    }
    
    .step-complete {
        background-color: #064e3b;
        border-color: #059669;
        color: #6ee7b7;
    }

    .eval-pass {
        color: #34d399;
        font-weight: bold;
    }
    
    .eval-retry {
        color: #f87171;
        font-weight: bold;
    }
</style>
""", unsafe_allow_html=True)

# Session State Initialization
if "messages" not in st.session_state:
    st.session_state.messages = []
if "conversation_id" not in st.session_state:
    st.session_state.conversation_id = None
if "active_document_id" not in st.session_state:
    st.session_state.active_document_id = None
if "active_document" not in st.session_state:
    st.session_state.active_document = None
if "last_response" not in st.session_state:
    st.session_state.last_response = None

# Sidebar Setup
with st.sidebar:
    st.title("🧠 Agent Control Center")
    st.markdown("Production-Quality **Self-Learning AI Agent** based on *Dave Ebbelaar* principles.")
    st.divider()

    # System Status Card
    st.subheader("⚙️ System Status")
    status_col1, status_col2 = st.columns(2)
    with status_col1:
        st.caption("Provider")
        st.code(settings.LLM_PROVIDER.upper())
    with status_col2:
        st.caption("API Key")
        if settings.is_api_key_configured:
            st.success("Configured")
        else:
            st.warning("Mock Mode")

    st.divider()

    # Document Upload Section (RAG)
    st.subheader("📄 Knowledge Base RAG")
    uploaded_file = st.file_uploader("Upload PDF, TXT, or Markdown", type=["pdf", "txt", "md"])
    if uploaded_file is not None:
        save_path = settings.KNOWLEDGE_DIR / uploaded_file.name
        if not save_path.exists() or save_path.stat().st_size != len(uploaded_file.getbuffer()):
            with open(save_path, "wb") as f:
                f.write(uploaded_file.getbuffer())
        
        conv_id = st.session_state.conversation_id
        if not conv_id:
            conv_id = memory_db.ensure_conversation(None)
            st.session_state.conversation_id = conv_id

        current_active_doc = memory_db.get_active_document(conv_id)
        index_clicked = st.button("Index Document", type="primary", use_container_width=True)

        if index_clicked or current_active_doc != uploaded_file.name:
            with st.spinner("Processing & Indexing document..."):
                chunks, msg = rag_engine.ingest_file(save_path, conversation_id=conv_id)
                if chunks > 0:
                    doc_id = memory_db.get_active_document_id(conv_id)
                    st.session_state.active_document_id = doc_id
                    st.session_state.active_document = uploaded_file.name
                    st.success(f"Indexed '{uploaded_file.name}'! {chunks} text chunks bound to conversation.")
                    
                    # TRACE 2 — CONVERSATION VERIFICATION LOG
                    from app.logger import logger
                    logger.info(
                        f"\nTRACE 2 — CONVERSATION VERIFICATION:\n"
                        f"current_conversation_id = {conv_id}\n"
                        f"current_session_id = {conv_id}\n"
                        f"active_document_id = {doc_id}\n"
                        f"st.session_state.conversation_id = {st.session_state.conversation_id}\n"
                        f"st.session_state.active_document_id = {st.session_state.active_document_id}"
                    )
                else:
                    st.error(msg)

    st.divider()

    # Memory Inspector Section
    st.subheader("🔍 Memory & Learning Inspector")
    inspector_tab1, inspector_tab2 = st.tabs(["Memories", "Learned Experiences"])
    
    with inspector_tab1:
        mems = memory_db.list_all_memories()
        if mems:
            for m in mems[:8]:
                st.markdown(f"**[{m.category}]** {m.content}")
                st.caption(f"Added: {m.created_at[:16]}")
                st.divider()
        else:
            st.info("No long-term memories saved yet.")

    with inspector_tab2:
        experiences = memory_db.get_relevant_learning_experiences(query="", task_type="GENERAL_KNOWLEDGE", limit=5)
        if experiences:
            for exp in experiences:
                outcome_icon = "✅ PASS" if exp.success else "🔄 RETRY"
                fb_icon = " 👍 Rated Helpful" if exp.user_feedback is True else (" 👎 Rated Not Helpful" if exp.user_feedback is False else "")
                st.markdown(f"**Task:** `{exp.task_type}` | **Status:** {outcome_icon}{fb_icon}")
                st.markdown(f"**Score:** `{exp.score}/100` | **Tools:** `{', '.join(exp.tools_used)}`")
                if exp.feedback_comment:
                    st.warning(f"💡 User Feedback Lesson: {exp.feedback_comment}")
                st.caption(f"Query: {exp.user_query[:50]}...")
                st.divider()
        else:
            st.info("No learning experiences logged yet.")

    st.divider()
    if st.button("Clear Conversation", use_container_width=True):
        st.session_state.messages = []
        st.session_state.conversation_id = None
        st.session_state.last_response = None
        st.rerun()

# Main Title & Header
st.title("🤖 Self-Learning AI Agent")
st.markdown("Capable of **Goal Understanding**, **Parallel Tool Calling**, **RAG Retrieval**, **Long-Term Memory**, **Self-Evaluation**, and **Feedback-Based Self-Improvement**.")

# Display Chat History
for msg in st.session_state.messages:
    with st.chat_message(msg["role"]):
        st.markdown(msg["content"])
        
        # Display metadata details for assistant messages
        if msg["role"] == "assistant" and "metadata" in msg:
            meta = msg["metadata"]
            
            # Tools & Evaluation Summary
            col_a, col_b, col_c = st.columns(3)
            with col_a:
                st.caption("Tools Used:")
                st.write(", ".join(meta.get("tools_used", [])) or "None")
            with col_b:
                st.caption("Evaluation Score:")
                score = meta.get("score", 0)
                st.markdown(f"**{score}/100** ({'PASS' if score >= 70 else 'RETRY'})")
            with col_c:
                st.caption("Attempts:")
                st.markdown(f"**{meta.get('attempts', 1)} attempt(s)**")

            # Feedback Buttons
            msg_id = meta.get("message_id")
            if msg_id:
                fcol1, fcol2, fcol3 = st.columns([1, 1, 6])
                with fcol1:
                    if st.button("👍 Helpful", key=f"up_{msg_id}"):
                        feedback_handler.process_feedback(msg_id, True)
                        st.toast("Recorded positive feedback!", icon="👍")
                with fcol2:
                    if st.button("👎 Not Helpful", key=f"down_{msg_id}"):
                        feedback_handler.process_feedback(msg_id, False)
                        st.toast("Recorded feedback for agent self-improvement!", icon="👎")

# User Input Box
user_prompt = st.chat_input("Ask a question, request math, search docs, or tell me to remember something...")

if user_prompt:
    # Append User Message
    st.session_state.messages.append({"role": "user", "content": user_prompt})
    with st.chat_message("user"):
        st.markdown(user_prompt)

    with st.chat_message("assistant"):
        # Activity Status Indicator Panel
        activity_container = st.container()
        with activity_container:
            st.markdown("#### ⚡ Agent Activity Trace")
            step_placeholder = st.empty()
            step_placeholder.markdown(
                '<span class="step-badge step-active">Understanding request</span> → '
                '<span class="step-badge">Planning</span> → '
                '<span class="step-badge">Selecting tool</span> → '
                '<span class="step-badge">Executing tool</span> → '
                '<span class="step-badge">Retrieving knowledge</span> → '
                '<span class="step-badge">Generating answer</span> → '
                '<span class="step-badge">Evaluating</span>',
                unsafe_allow_html=True
            )

        with st.spinner("Agent is reasoning and executing tools..."):
            # Run Agent Loop
            req = ChatRequest(
                query=user_prompt,
                conversation_id=st.session_state.conversation_id
            )
            
            # Execute async agent loop in event loop
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            response = loop.run_until_complete(agent.run(req))
            
            st.session_state.conversation_id = response.conversation_id
            st.session_state.last_response = response

        # Update Activity Trace to Completed
        with activity_container:
            step_placeholder.markdown(
                '<span class="step-badge step-complete">Understanding request</span> → '
                '<span class="step-badge step-complete">Planning</span> → '
                '<span class="step-badge step-complete">Tool Selected</span> → '
                '<span class="step-badge step-complete">Tool Executed</span> → '
                '<span class="step-badge step-complete">Generating answer</span> → '
                '<span class="step-badge step-complete">Evaluated</span> → '
                f'<span class="step-badge step-complete">Completed ({response.attempts} attempt)</span>',
                unsafe_allow_html=True
            )

        # Display Final Answer
        st.markdown(response.answer)

        # Display Activity Steps & Evaluation Accordion
        with st.expander("📊 Execution Traces & Self-Evaluation Details", expanded=True):
            tab_steps, tab_eval, tab_rag = st.tabs(["Activity Steps", "Self-Evaluation", "Retrieved Context"])
            
            with tab_steps:
                for step in response.steps:
                    st.markdown(f"**• {step.step_name}:** {step.description}")

            with tab_eval:
                ev = response.evaluation
                m1, m2, m3, m4 = st.columns(4)
                m1.metric("Relevance", f"{ev.relevance_score}/10")
                m2.metric("Correctness", f"{ev.correctness_score}/10")
                m3.metric("Completeness", f"{ev.completeness_score}/10")
                m4.metric("Total Score", f"{ev.total_score}/100")
                
                st.markdown(f"**Status:** `{'PASS' if ev.status == 'PASS' else 'RETRY'}`")
                st.markdown(f"**Feedback:** {ev.improvement_feedback}")

            with tab_rag:
                if response.rag_context:
                    for ctx in response.rag_context:
                        st.info(ctx)
                else:
                    st.write("No external RAG chunks retrieved.")

        # Interactive Feedback Buttons for live response
        msg_id = response.message_id
        fcol1, fcol2, fcol3 = st.columns([1, 1, 6])
        with fcol1:
            if st.button("👍 Helpful", key=f"live_up_{msg_id}"):
                feedback_handler.process_feedback(msg_id, True)
                st.toast("Recorded positive feedback!", icon="👍")
        with fcol2:
            if st.button("👎 Not Helpful", key=f"live_down_{msg_id}"):
                feedback_handler.process_feedback(msg_id, False)
                st.toast("Recorded feedback for agent self-improvement!", icon="👎")

        # Save into session state messages
        st.session_state.messages.append({
            "role": "assistant",
            "content": response.answer,
            "metadata": {
                "message_id": msg_id,
                "tools_used": response.tools_used,
                "score": response.score,
                "attempts": response.attempts
            }
        })
