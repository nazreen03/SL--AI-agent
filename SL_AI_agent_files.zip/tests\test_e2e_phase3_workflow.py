import pytest
import asyncio
from app.schemas import ChatRequest
from app.agent import agent
from app.memory import memory_db

def test_e2e_phase3_full_workflow():
    """
    End-to-End Validation of Phase 3 Workflow:
    1. Conversation 1: User provides fact ("My favorite programming language is Java.") -> Memory stored.
    2. New Conversation 2: User asks ("What is my favorite programming language?") -> Memory retrieved & LLM generates answer ("Java").
    3. Conversation 2: User updates fact ("My favorite programming language is Python now.") -> Memory updated.
    4. Verify no duplicate memory created in SQLite DB (memory count for topic is 1).
    5. New Conversation 3: User asks ("What is my favorite programming language?") -> Memory retrieved & LLM generates answer ("Python").
    """
    # Clear memories for fresh E2E test execution
    with memory_db._get_connection() as conn:
        conn.cursor().execute("DELETE FROM memories")
        conn.commit()

    # Step 1: Conversation 1 - User provides initial fact
    conv1_id = "conv-session-e2e-1"
    req1 = ChatRequest(
        query="My favorite programming language is Java.",
        conversation_id=conv1_id
    )
    res1 = asyncio.run(agent.run(req1))
    
    # Check DB state after Step 1
    mems_after_step1 = memory_db.list_all_memories()
    assert len(mems_after_step1) == 1, f"Expected 1 memory after step 1, found {len(mems_after_step1)}"
    assert "Java" in mems_after_step1[0].content, f"Expected Java in memory, got {mems_after_step1[0].content}"
    initial_mem_id = mems_after_step1[0].id

    # Step 2: Conversation 2 (NEW conversation) - User asks related question
    conv2_id = "conv-session-e2e-2"
    req2 = ChatRequest(
        query="What is my favorite programming language?",
        conversation_id=conv2_id
    )
    res2 = asyncio.run(agent.run(req2))
    assert "Java" in res2.answer or "java" in res2.answer.lower(), f"Expected Java in res2 answer, got: '{res2.answer}'"

    # Step 3: Conversation 2 - User updates the fact
    req3 = ChatRequest(
        query="My favorite programming language is Python now.",
        conversation_id=conv2_id
    )
    res3 = asyncio.run(agent.run(req3))

    # Step 4: Verify memory updated in-place and NO duplicate created
    mems_after_step3 = memory_db.list_all_memories()
    assert len(mems_after_step3) == 1, f"Expected 1 memory after update (no duplicates), found {len(mems_after_step3)}"
    assert mems_after_step3[0].id == initial_mem_id, "Memory ID should be reused/updated"
    assert "Python" in mems_after_step3[0].content, f"Expected Python in memory, got {mems_after_step3[0].content}"

    # Step 5: Conversation 3 (NEW conversation) - User asks question again
    conv3_id = "conv-session-e2e-3"
    req4 = ChatRequest(
        query="What is my favorite programming language?",
        conversation_id=conv3_id
    )
    res4 = asyncio.run(agent.run(req4))
    assert "Python" in res4.answer or "python" in res4.answer.lower(), f"Expected Python in res4 answer, got: '{res4.answer}'"
    print("E2E Phase 3 Workflow test PASSED cleanly!")

if __name__ == "__main__":
    test_e2e_phase3_full_workflow()
