import pytest
import asyncio
import tempfile
import os
from pathlib import Path
from app.memory import MemoryDatabase, memory_db
from app.schemas import ChatRequest
from app.agent import agent
from app.planner import planner

@pytest.fixture
def temp_db():
    with tempfile.NamedTemporaryFile(suffix=".db", delete=False) as f:
        db_path = Path(f.name)
    db = MemoryDatabase(db_path=db_path)
    yield db
    try:
        if db_path.exists():
            os.remove(db_path)
    except Exception:
        pass

def test_negative_feedback_storage(temp_db):
    msg_id = temp_db.add_message("conv-1", "user", "Explain recursion to a beginner.")
    temp_db.record_learning_experience(
        task_type="GENERAL_KNOWLEDGE",
        user_query="Explain recursion to a beginner.",
        approach_summary="Provided standard technical definition",
        tools_used=[],
        score=90,
        success=True
    )
    temp_db.record_user_feedback(
        message_id=msg_id,
        is_helpful=False,
        comment="Too complicated. Explain it using a very simple real-world example."
    )
    
    exps = temp_db.get_relevant_learning_experiences(query="recursion", task_type="GENERAL_KNOWLEDGE")
    assert len(exps) == 1
    assert exps[0].user_feedback is False
    assert exps[0].feedback_comment == "Too complicated. Explain it using a very simple real-world example."

def test_positive_feedback_storage(temp_db):
    msg_id = temp_db.add_message("conv-2", "user", "What is 2 + 2?")
    temp_db.record_learning_experience(
        task_type="CALCULATION",
        user_query="What is 2 + 2?",
        approach_summary="Executed calculator tool",
        tools_used=["calculator"],
        score=95,
        success=True
    )
    temp_db.record_user_feedback(
        message_id=msg_id,
        is_helpful=True,
        comment="Great simple answer!"
    )
    
    exps = temp_db.get_relevant_learning_experiences(query="2 + 2", task_type="CALCULATION")
    assert len(exps) == 1
    assert exps[0].user_feedback is True
    assert exps[0].feedback_comment == "Great simple answer!"

def test_learning_experience_retrieval(temp_db):
    msg_id = temp_db.add_message("conv-3", "user", "Explain recursion to a beginner.")
    temp_db.record_learning_experience(
        task_type="GENERAL_KNOWLEDGE",
        user_query="Explain recursion to a beginner.",
        approach_summary="Technical definition",
        tools_used=[],
        score=85,
        success=True
    )
    temp_db.record_user_feedback(
        message_id=msg_id,
        is_helpful=False,
        comment="Too technical. Use real-world analogies."
    )
    
    fetched = temp_db.get_relevant_learning_experiences(query="Explain binary search to me", task_type="GENERAL_KNOWLEDGE")
    assert len(fetched) >= 1
    assert fetched[0].feedback_comment == "Too technical. Use real-world analogies."

def test_strategy_adaptation():
    # Use memory_db global instance
    msg_id = memory_db.add_message("conv-4", "user", "Explain recursion to a beginner.")
    memory_db.record_learning_experience(
        task_type="GENERAL_KNOWLEDGE",
        user_query="Explain recursion to a beginner.",
        approach_summary="Technical definition",
        tools_used=[],
        score=80,
        success=True
    )
    memory_db.record_user_feedback(
        message_id=msg_id,
        is_helpful=False,
        comment="Too complicated. Explain it using a very simple real-world example."
    )
    
    plan = planner.plan("Explain binary search to me.", chat_history=[])
    assert plan.past_experience_hint is not None
    assert "CRITICAL USER LESSON" in plan.past_experience_hint
    assert "Too complicated" in plan.past_experience_hint

def test_activity_trace_visibility():
    msg_id = memory_db.add_message("conv-5", "user", "Explain recursion to a beginner.")
    memory_db.record_learning_experience(
        task_type="GENERAL_KNOWLEDGE",
        user_query="Explain recursion to a beginner.",
        approach_summary="Technical definition",
        tools_used=[],
        score=80,
        success=True
    )
    memory_db.record_user_feedback(
        message_id=msg_id,
        is_helpful=False,
        comment="Too complicated. Explain it using a very simple real-world example."
    )
    
    req = ChatRequest(query="Explain binary search to me.", conversation_id="conv-trace-test")
    res = asyncio.run(agent.run(req))
    
    step_names = [s.step_name for s in res.steps]
    assert "Retrieved relevant learning experience" in step_names
    assert "Adapted strategy" in step_names

def test_before_after_strategy_and_response():
    # Clear learning experiences for clean before/after comparison
    with memory_db._get_connection() as conn:
        conn.cursor().execute("DELETE FROM learning_experiences")
        conn.commit()

    # BEFORE feedback:
    req_before = ChatRequest(query="Explain recursion to a beginner.", conversation_id="conv-before")
    res_before = asyncio.run(agent.run(req_before))
    answer_before = res_before.answer
    score_before = res_before.score

    # User submits negative feedback on response
    memory_db.record_user_feedback(
        message_id=res_before.message_id,
        is_helpful=False,
        comment="Too complicated. Explain it using a very simple real-world example."
    )

    # AFTER feedback on similar task ("Explain binary search to me."):
    req_after = ChatRequest(query="Explain binary search to me.", conversation_id="conv-after")
    res_after = asyncio.run(agent.run(req_after))
    answer_after = res_after.answer
    score_after = res_after.score

    # Check evidence of adapted strategy & real-world analogy in response
    assert any(kw in answer_after.lower() for kw in ["dictionary", "phonebook", "middle", "analog", "doll"])
    print(f"BEFORE answer: '{answer_before[:60]}...' (Score: {score_before})")
    print(f"AFTER answer: '{answer_after[:60]}...' (Score: {score_after})")

def test_learning_persistence_after_restart():
    with tempfile.NamedTemporaryFile(suffix=".db", delete=False) as f:
        db_path = Path(f.name)
    
    db1 = MemoryDatabase(db_path=db_path)
    msg_id = db1.add_message("c1", "user", "Explain sorting algorithms")
    db1.record_learning_experience(
        task_type="GENERAL_KNOWLEDGE",
        user_query="Explain sorting algorithms",
        approach_summary="Listed all algorithms",
        tools_used=[],
        score=75,
        success=True
    )
    db1.record_user_feedback(
        message_id=msg_id,
        is_helpful=False,
        comment="Include a real-world example of quicksort."
    )
    
    # Restart app / instantiate new MemoryDatabase on same file
    db2 = MemoryDatabase(db_path=db_path)
    exps = db2.get_relevant_learning_experiences("sorting", "GENERAL_KNOWLEDGE")
    assert len(exps) == 1
    assert exps[0].feedback_comment == "Include a real-world example of quicksort."
    
    try:
        os.remove(db_path)
    except Exception:
        pass

def test_duplicate_learning_prevention(temp_db):
    id1 = temp_db.record_learning_experience(
        task_type="GENERAL_KNOWLEDGE",
        user_query="Explain recursion to a beginner.",
        approach_summary="Approach 1",
        tools_used=[],
        score=70,
        success=True
    )
    id2 = temp_db.record_learning_experience(
        task_type="GENERAL_KNOWLEDGE",
        user_query="Explain recursion to a beginner.",
        approach_summary="Approach 2 with improvements",
        tools_used=[],
        score=90,
        success=True
    )
    assert id1 == id2
    exps = temp_db.get_relevant_learning_experiences("recursion", "GENERAL_KNOWLEDGE")
    assert len(exps) == 1
    assert exps[0].score == 90
