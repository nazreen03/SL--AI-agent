from typing import Optional
from app.schemas import EvaluationResult, IntentCategory
from app.llm import llm_client
from app.prompts import EVALUATOR_PROMPT
from app.config import settings
from app.logger import logger

class AgentEvaluator:
    """Self-Evaluation engine evaluating relevance, correctness, completeness, and context grounding."""

    def evaluate(
        self,
        query: str,
        answer: str,
        context: str,
        intent: Optional[IntentCategory] = None,
        has_tool_failure: bool = False
    ) -> EvaluationResult:
        logger.info("Running Self-Evaluation on generated response...")

        # 1. Enforcement Check: Tool Failure Penalty
        if has_tool_failure:
            logger.warning("Evaluation failure: Tool execution failed during attempt.")
            return EvaluationResult(
                relevance_score=3,
                correctness_score=2,
                completeness_score=3,
                total_score=30,
                status="RETRY",
                improvement_feedback="Tool execution failed or returned invalid output. Select proper tool or fix arguments.",
                task_completed=False,
                context_used_properly=False
            )

        # 2. Enforcement Check: Document Grounding Penalty
        is_doc_intent = intent in [IntentCategory.DOCUMENT_QUESTION, IntentCategory.DOCUMENT_SUMMARY, IntentCategory.DOCUMENT_RAG]
        has_retrieved_chunks = any(kw in context for kw in ["Retrieved", "Full Document Content", "Document Content", "Similarity:"])
        
        if is_doc_intent and not has_retrieved_chunks:
            if "I couldn't find that information in the uploaded document." not in answer:
                logger.warning("Evaluation failure: Document question answered without retrieving document context.")
                return EvaluationResult(
                    relevance_score=2,
                    correctness_score=2,
                    completeness_score=2,
                    total_score=20,
                    status="RETRY",
                    improvement_feedback="Question required uploaded document grounding, but no valid document chunks were retrieved.",
                    task_completed=False,
                    context_used_properly=False
                )

        prompt = EVALUATOR_PROMPT.format(
            query=query,
            answer=answer,
            context=context or "No external context or tool output required.",
            pass_score=settings.EVALUATION_PASS_SCORE
        )

        eval_res = llm_client.generate_structured(
            prompt=prompt,
            response_schema=EvaluationResult,
            system_prompt="Evaluate the generated AI Agent response objectively."
        )

        # Enforce threshold consistency
        if eval_res.total_score >= settings.EVALUATION_PASS_SCORE:
            eval_res.status = "PASS"
        else:
            eval_res.status = "RETRY"

        logger.info(f"Self-Evaluation Result: Score={eval_res.total_score}/100, Status={eval_res.status}")
        return eval_res

evaluator = AgentEvaluator()

