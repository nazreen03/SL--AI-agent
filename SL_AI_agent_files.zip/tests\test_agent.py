import pytest
from app.agent import agent
from app.schemas import ChatRequest, ChatResponse

@pytest.mark.asyncio
async def test_agent_calculation_flow():
    req = ChatRequest(query="Calculate 45 * 12")
    res = await agent.run(req)
    assert isinstance(res, ChatResponse)
    assert res.score >= 50
    assert "calculator" in res.tools_used or res.score > 0
    assert len(res.steps) > 0

@pytest.mark.asyncio
async def test_agent_memory_flow():
    # Save fact
    req1 = ChatRequest(query="Remember that my favorite language is Python")
    res1 = await agent.run(req1)
    assert isinstance(res1, ChatResponse)
    
    # Recall memory
    req2 = ChatRequest(query="What is my favorite language?", conversation_id=res1.conversation_id)
    res2 = await agent.run(req2)
    assert isinstance(res2, ChatResponse)
    assert res2.score > 0
