import pytest
import tempfile
from pathlib import Path
from app.memory import memory_db
from app.rag import rag_engine
from app.agent import agent
from app.schemas import ChatRequest

@pytest.mark.asyncio
async def test_trace_1_2_3_4_end_to_end():
    # 1. Create a sample PDF/TXT file
    with tempfile.NamedTemporaryFile(suffix=".txt", delete=False, mode="w", encoding="utf-8") as f:
        f.write("Artificial Intelligence Agent Specification Document. This document describes autonomous agent design with RAG memory.")
        sample_path = Path(f.name)

    conv_id = memory_db.ensure_conversation(None)
    assert conv_id is not None

    # TRACE 1 — UPLOAD
    chunks_created, status_msg = rag_engine.ingest_file(sample_path, conversation_id=conv_id)
    assert chunks_created > 0

    uploaded_doc_id = memory_db.get_active_document_id(conv_id)
    assert uploaded_doc_id is not None

    doc_meta = memory_db.get_document_by_id(uploaded_doc_id)
    assert doc_meta is not None
    assert doc_meta["filename"] == sample_path.name
    assert doc_meta["conversation_id"] == conv_id

    # TRACE 2 — CONVERSATION VERIFICATION
    db_active_doc_id = memory_db.get_active_document_id(conv_id)
    db_active_doc = memory_db.get_active_document(conv_id)
    assert db_active_doc_id == uploaded_doc_id
    assert db_active_doc == sample_path.name

    # TRACE 3 — CHAT REQUEST & TRACE 4 — DOCUMENT LOOKUP
    req = ChatRequest(query="summarize", conversation_id=conv_id)
    response = await agent.run(req)

    assert response.conversation_id == conv_id
    assert "No active document found for this conversation." not in response.answer
    assert "Please upload a document" not in response.answer
    assert len(response.answer) > 10
